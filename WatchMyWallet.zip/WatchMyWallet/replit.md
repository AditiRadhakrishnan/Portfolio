# Overview

This is a comprehensive personal finance management application built with React and Express. The app provides a complete dashboard for tracking expenses, managing budgets, monitoring savings goals, and visualizing financial data. It features a modern UI built with shadcn/ui components and Tailwind CSS, with a focus on providing users with clear insights into their spending patterns and financial health.

# User Preferences

Preferred communication style: Simple, everyday language.

## Developer Information
- **Developer**: Aditi Radhakrishnan
- **Email**: aditirad3277@gmail.com
- **Phone**: (209) 740-2314
- **Date Added**: August 18, 2025
- **Features Added**: Developer credits section with contact info, profile picture, technologies used, and mission statement

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **Routing**: Wouter for client-side routing
- **State Management**: React Query (@tanstack/react-query) for server state and React hooks for local state
- **Forms**: React Hook Form with Zod validation schemas
- **Data Visualization**: Recharts for financial charts and graphs

## Backend Architecture
- **Framework**: Express.js with TypeScript
- **Development Setup**: tsx for TypeScript execution in development
- **Build Tool**: esbuild for production builds
- **Module System**: ESM (ES Modules) throughout the application
- **Storage Interface**: Abstracted storage layer with in-memory implementation for development

## Data Storage Solutions
- **Production Database**: PostgreSQL configured via Drizzle ORM
- **Database Provider**: Neon Database (@neondatabase/serverless)
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Development Storage**: In-memory storage with localStorage fallback for client-side persistence
- **Session Management**: PostgreSQL session store (connect-pg-simple)

## Database Schema Design
The application uses a well-structured financial data model with four main entities:
- **Expenses**: Tracks individual spending with categories, amounts, and dates
- **Budgets**: Manages spending limits per category with automatic spent amount tracking
- **Savings Goals**: Handles target-based savings with progress tracking
- **Income**: Records income sources and amounts

All tables include UUID primary keys, timestamps, and proper decimal precision for monetary values.

## Development vs Production Architecture
- **Development**: Uses in-memory storage with automatic data persistence to localStorage
- **Production**: Full PostgreSQL integration with Drizzle ORM
- **Hot Reload**: Vite development server with HMR support
- **Error Handling**: Runtime error overlay in development mode

## Component Architecture
- **Modular Design**: Separate components for each major feature (dashboard, expenses, budgets, savings goals)
- **Modal System**: Reusable modal components for data entry and editing
- **UI Components**: Comprehensive shadcn/ui component library with consistent theming
- **Responsive Design**: Mobile-first approach with adaptive layouts

# External Dependencies

## Core Framework Dependencies
- **@vitejs/plugin-react**: React plugin for Vite build system
- **wouter**: Lightweight client-side routing library
- **@tanstack/react-query**: Server state management and caching

## Database and ORM
- **drizzle-orm**: TypeScript-first ORM for database operations
- **drizzle-kit**: CLI tool for database migrations and schema management
- **@neondatabase/serverless**: Serverless PostgreSQL database driver
- **drizzle-zod**: Integration between Drizzle ORM and Zod validation

## UI and Styling
- **@radix-ui/react-***: Comprehensive set of unstyled, accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Type-safe variant API for component styling
- **clsx**: Utility for constructing className strings conditionally

## Form Handling and Validation
- **react-hook-form**: Performant forms with easy validation
- **@hookform/resolvers**: Validation resolvers for react-hook-form
- **zod**: TypeScript-first schema validation library

## Data Visualization
- **recharts**: Composable charting library for React applications

## Development Tools
- **tsx**: TypeScript execution environment for Node.js
- **esbuild**: Fast JavaScript bundler for production builds
- **Development Error Handling**: Runtime error overlay for better debugging
- **Development Tooling**: Enhanced development environment support

## Utility Libraries
- **date-fns**: Modern JavaScript date utility library
- **nanoid**: URL-safe unique ID generator
- **cmdk**: Command menu component for search and navigation
- **embla-carousel-react**: Carousel component library