import { useState } from 'react';
import { ChevronDown, ChevronRight, Shield, BookOpen, Video, HelpCircle, Lock, Eye, EyeOff, AlertTriangle } from 'lucide-react';

export default function Help() {
  const [activeSection, setActiveSection] = useState<string>('getting-started');
  const [expandedFaq, setExpandedFaq] = useState<string | null>(null);

  const sections = [
    { id: 'getting-started', title: 'Getting Started', icon: BookOpen },
    { id: 'tutorials', title: 'Tutorials', icon: Video },
    { id: 'faqs', title: 'FAQs', icon: HelpCircle },
    { id: 'security', title: 'Security & Privacy', icon: Shield },
  ];

  const tutorials = [
    {
      title: 'Setting Up Your First Budget',
      duration: '3 min',
      steps: [
        'Navigate to the Budget Management section',
        'Click "Add Budget" and enter a category (e.g., "Food")',
        'Set your monthly spending limit',
        'Track your progress as you add expenses'
      ]
    },
    {
      title: 'Tracking Daily Expenses',
      duration: '2 min',
      steps: [
        'Use the orange "Expense Tracking" button for quick access',
        'Click "Add Expense" and fill in the details',
        'Choose the appropriate category',
        'Review your spending patterns in the charts'
      ]
    },
    {
      title: 'Creating Savings Goals',
      duration: '4 min',
      steps: [
        'Click the green "Savings Goals" button',
        'Set a target amount and deadline',
        'Add money to your goal regularly',
        'Watch your progress with visual indicators'
      ]
    },
    {
      title: 'Using the Salary Calculator',
      duration: '5 min',
      steps: [
        'Enter your annual or hourly salary',
        'Review the 50/30/20 budget breakdown',
        'Use recommendations for spending limits',
        'Adjust based on your personal situation'
      ]
    }
  ];

  const faqs = [
    {
      question: 'Where is my financial data stored?',
      answer: 'All your financial data is stored locally on your device using your browser\'s local storage. This means your sensitive information never leaves your computer and is completely private.'
    },
    {
      question: 'Can I export my financial data?',
      answer: 'Currently, your data is automatically saved to your browser\'s local storage. For backup purposes, you can manually record your key financial information or take screenshots of your dashboard.'
    },
    {
      question: 'What is the 50/30/20 budgeting rule?',
      answer: 'This popular budgeting method allocates 50% of after-tax income to needs, 30% to wants, and 20% to savings and debt repayment. Our salary calculator uses this as a starting point for your budget recommendations.'
    },
    {
      question: 'How do I delete or edit an expense?',
      answer: 'In the Expense Tracker section, you\'ll find edit and delete buttons next to each expense entry. Click these to modify or remove transactions as needed.'
    },
    {
      question: 'Can multiple people use the same account?',
      answer: 'Each browser session maintains its own data. For shared finances, we recommend one person manages the account and shares access, or each person tracks their portion separately.'
    },
    {
      question: 'Why aren\'t my charts showing data?',
      answer: 'Charts require data to display. Start by adding some expenses, income, or budget categories. Once you have entries, the visual charts will automatically populate with your information.'
    },
    {
      question: 'How often should I update my budget?',
      answer: 'Review and update your budget monthly. Adjust categories based on actual spending patterns, and modify limits as your financial situation changes.'
    },
    {
      question: 'What happens if I clear my browser data?',
      answer: 'Clearing browser data will remove all your financial information since data is stored locally. Be cautious when clearing browser storage and consider backing up important financial records.'
    }
  ];

  const securityTips = [
    {
      title: 'Local Data Storage',
      description: 'Your financial data is stored only on your device, ensuring complete privacy.',
      icon: Lock
    },
    {
      title: 'Regular Browser Updates',
      description: 'Keep your browser updated for the latest security features and protections.',
      icon: Shield
    },
    {
      title: 'Secure Device Access',
      description: 'Use strong passwords and enable device locking to protect your financial information.',
      icon: Eye
    },
    {
      title: 'Public Computer Caution',
      description: 'Avoid accessing financial data on public or shared computers.',
      icon: AlertTriangle
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Help & Support</h1>
              <p className="text-gray-600 dark:text-gray-400">Learn how to make the most of WatchMyWallet</p>
            </div>
            <button 
              onClick={() => window.history.back()}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
            >
              Back to Dashboard
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar Navigation */}
          <div className="lg:col-span-1">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 sticky top-8">
              <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Quick Navigation</h3>
              <nav className="space-y-2">
                {sections.map((section) => (
                  <button
                    key={section.id}
                    onClick={() => setActiveSection(section.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-colors ${
                      activeSection === section.id
                        ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300'
                        : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`}
                  >
                    <section.icon className="w-4 h-4" />
                    {section.title}
                  </button>
                ))}
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {activeSection === 'getting-started' && (
              <div className="space-y-6">
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Getting Started with WatchMyWallet</h2>
                  
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h3 className="font-semibold text-gray-900 dark:text-white">Quick Start Steps</h3>
                      <ol className="space-y-3 text-gray-600 dark:text-gray-400">
                        <li className="flex items-start gap-3">
                          <span className="flex-shrink-0 w-6 h-6 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded-full flex items-center justify-center text-sm font-medium">1</span>
                          <span>Start by adding your income using the yellow "Income Tracking" button</span>
                        </li>
                        <li className="flex items-start gap-3">
                          <span className="flex-shrink-0 w-6 h-6 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded-full flex items-center justify-center text-sm font-medium">2</span>
                          <span>Use the salary calculator to set up a recommended budget</span>
                        </li>
                        <li className="flex items-start gap-3">
                          <span className="flex-shrink-0 w-6 h-6 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded-full flex items-center justify-center text-sm font-medium">3</span>
                          <span>Create budget categories for your major expense types</span>
                        </li>
                        <li className="flex items-start gap-3">
                          <span className="flex-shrink-0 w-6 h-6 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded-full flex items-center justify-center text-sm font-medium">4</span>
                          <span>Begin tracking your daily expenses and watch your progress</span>
                        </li>
                      </ol>
                    </div>

                    <div className="space-y-4">
                      <h3 className="font-semibold text-gray-900 dark:text-white">Key Features</h3>
                      <div className="space-y-3">
                        <div className="flex items-center gap-3 p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                          <div className="w-8 h-8 bg-orange-200 dark:bg-orange-800 rounded-lg flex items-center justify-center">
                            <span className="text-orange-600 text-sm">💰</span>
                          </div>
                          <span className="text-sm text-gray-700 dark:text-gray-300">Expense Tracking</span>
                        </div>
                        <div className="flex items-center gap-3 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                          <div className="w-8 h-8 bg-blue-200 dark:bg-blue-800 rounded-lg flex items-center justify-center">
                            <span className="text-blue-600 text-sm">📊</span>
                          </div>
                          <span className="text-sm text-gray-700 dark:text-gray-300">Budget Management</span>
                        </div>
                        <div className="flex items-center gap-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                          <div className="w-8 h-8 bg-green-200 dark:bg-green-800 rounded-lg flex items-center justify-center">
                            <span className="text-green-600 text-sm">🎯</span>
                          </div>
                          <span className="text-sm text-gray-700 dark:text-gray-300">Savings Goals</span>
                        </div>
                        <div className="flex items-center gap-3 p-3 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg">
                          <div className="w-8 h-8 bg-indigo-200 dark:bg-indigo-800 rounded-lg flex items-center justify-center">
                            <span className="text-indigo-600 text-sm">🧮</span>
                          </div>
                          <span className="text-sm text-gray-700 dark:text-gray-300">Salary Calculator</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeSection === 'tutorials' && (
              <div className="space-y-6">
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">Step-by-Step Tutorials</h2>
                  
                  <div className="grid gap-6">
                    {tutorials.map((tutorial, index) => (
                      <div key={index} className="border border-gray-200 dark:border-gray-600 rounded-lg p-6">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="font-semibold text-gray-900 dark:text-white">{tutorial.title}</h3>
                          <span className="text-sm text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded">
                            {tutorial.duration}
                          </span>
                        </div>
                        <ol className="space-y-2">
                          {tutorial.steps.map((step, stepIndex) => (
                            <li key={stepIndex} className="flex items-start gap-3 text-gray-600 dark:text-gray-400">
                              <span className="flex-shrink-0 w-5 h-5 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded-full flex items-center justify-center text-xs font-medium">
                                {stepIndex + 1}
                              </span>
                              {step}
                            </li>
                          ))}
                        </ol>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeSection === 'faqs' && (
              <div className="space-y-6">
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">Frequently Asked Questions</h2>
                  
                  <div className="space-y-4">
                    {faqs.map((faq, index) => (
                      <div key={index} className="border border-gray-200 dark:border-gray-600 rounded-lg">
                        <button
                          onClick={() => setExpandedFaq(expandedFaq === `faq-${index}` ? null : `faq-${index}`)}
                          className="w-full px-4 py-4 text-left flex items-center justify-between hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg transition-colors"
                        >
                          <span className="font-medium text-gray-900 dark:text-white pr-4">{faq.question}</span>
                          {expandedFaq === `faq-${index}` ? (
                            <ChevronDown className="w-5 h-5 text-gray-400 flex-shrink-0" />
                          ) : (
                            <ChevronRight className="w-5 h-5 text-gray-400 flex-shrink-0" />
                          )}
                        </button>
                        {expandedFaq === `faq-${index}` && (
                          <div className="px-4 pb-4 text-gray-600 dark:text-gray-400 border-t border-gray-200 dark:border-gray-600 pt-4">
                            {faq.answer}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeSection === 'security' && (
              <div className="space-y-6">
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">Security & Privacy Best Practices</h2>
                  
                  <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4 mb-6">
                    <div className="flex items-start gap-3">
                      <Shield className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <h3 className="font-medium text-green-800 dark:text-green-200">Your Data Stays Private</h3>
                        <p className="text-sm text-green-700 dark:text-green-300 mt-1">
                          WatchMyWallet stores all your financial information locally on your device. Your sensitive data never leaves your computer.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    {securityTips.map((tip, index) => (
                      <div key={index} className="border border-gray-200 dark:border-gray-600 rounded-lg p-4">
                        <div className="flex items-start gap-3">
                          <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center flex-shrink-0">
                            <tip.icon className="w-5 h-5 text-blue-600" />
                          </div>
                          <div>
                            <h3 className="font-medium text-gray-900 dark:text-white mb-2">{tip.title}</h3>
                            <p className="text-sm text-gray-600 dark:text-gray-400">{tip.description}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-8 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
                    <div className="flex items-start gap-3">
                      <AlertTriangle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <h3 className="font-medium text-yellow-800 dark:text-yellow-200">Data Backup Reminder</h3>
                        <p className="text-sm text-yellow-700 dark:text-yellow-300 mt-1">
                          Since your data is stored locally, clearing browser data will permanently remove your financial information. 
                          Consider periodically saving screenshots or manually recording important financial milestones.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}