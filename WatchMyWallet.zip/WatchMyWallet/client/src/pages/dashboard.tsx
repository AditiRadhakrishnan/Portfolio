import { useState, useEffect } from 'react';
import { storage } from '@/lib/storage';
import { FinanceData, Expense, Budget, SavingsGoal, Income, SalaryInfo } from '@/lib/types';
import DashboardOverview from '@/components/dashboard-overview';
import ExpenseTracker from '@/components/expense-tracker';
import BudgetSection from '@/components/budget-section';
import SavingsGoals from '@/components/savings-goals';
import { SalaryCalculator } from '@/components/salary-calculator';
import { IncomeModal } from '@/components/modals/income-modal';
import { Link } from 'wouter';
import { HelpCircle } from 'lucide-react';
import { CurrencySelector } from '@/components/currency-selector';
import { formatCurrency } from '@/lib/currency';
import profilePhoto from '@assets/IMG_3923_1755547484032.jpeg';

export default function Dashboard() {
  const [data, setData] = useState<FinanceData>({
    expenses: [],
    budgets: [],
    savingsGoals: [],
    income: [],
    salary: undefined,
  });
  const [showIncomeModal, setShowIncomeModal] = useState(false);

  // Load data from localStorage on mount
  useEffect(() => {
    const savedData = storage.getData();
    setData(savedData);
  }, []);

  // Update budget spent amounts whenever expenses change
  useEffect(() => {
    storage.updateBudgetSpent();
    setData(storage.getData());
  }, [data.expenses]);

  const handleAddExpense = (expense: Omit<Expense, 'id'>) => {
    storage.addExpense(expense);
    setData(storage.getData());
  };

  const handleUpdateExpense = (id: string, updates: Partial<Expense>) => {
    storage.updateExpense(id, updates);
    setData(storage.getData());
  };

  const handleDeleteExpense = (id: string) => {
    storage.deleteExpense(id);
    setData(storage.getData());
  };

  const handleAddBudget = (budget: Omit<Budget, 'id' | 'spent'>) => {
    storage.addBudget(budget);
    setData(storage.getData());
  };

  const handleUpdateBudget = (id: string, updates: Partial<Budget>) => {
    storage.updateBudget(id, updates);
    setData(storage.getData());
  };

  const handleDeleteBudget = (id: string) => {
    storage.deleteBudget(id);
    setData(storage.getData());
  };

  const handleAddSavingsGoal = (goal: Omit<SavingsGoal, 'id' | 'current'>) => {
    storage.addSavingsGoal(goal);
    setData(storage.getData());
  };

  const handleUpdateSavingsGoal = (id: string, updates: Partial<SavingsGoal>) => {
    storage.updateSavingsGoal(id, updates);
    setData(storage.getData());
  };

  const handleDeleteSavingsGoal = (id: string) => {
    storage.deleteSavingsGoal(id);
    setData(storage.getData());
  };

  const handleAddToSavingsGoal = (id: string, amount: number) => {
    storage.addToSavingsGoal(id, amount);
    setData(storage.getData());
  };

  const handleSalaryUpdate = (salary: SalaryInfo) => {
    storage.setSalary(salary);
    setData(storage.getData());
  };

  // Scroll to section functionality
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  // Income modal functionality
  const openIncomeModal = () => {
    setShowIncomeModal(true);
  };

  const handleAddIncome = (income: Omit<Income, 'id'>) => {
    storage.addIncome(income);
    setData(storage.getData());
  };

  const handleCurrencyChange = (currency: string) => {
    storage.setCurrency(currency);
    setData(storage.getData());
  };

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="flex justify-between items-start mb-8">
            <div className="text-center flex-1">
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">WatchMyWallet</h1>
              <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                Take control of your finances with our comprehensive personal finance management tools. 
                Track expenses, manage budgets, and achieve your savings goals all in one place.
              </p>
            </div>
            <div className="flex items-center gap-4 ml-6">
              <CurrencySelector
                selectedCurrency={data.currency || 'USD'}
                onCurrencyChange={handleCurrencyChange}
                size="sm"
              />
              <Link href="/help" className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors">
                <HelpCircle className="w-4 h-4" />
                Help & Tutorials
              </Link>
            </div>
          </div>

          {/* Financial Tools Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 mb-8">
            <button 
              onClick={() => scrollToSection('expense-tracker')} 
              className="bg-orange-50 dark:bg-orange-900/20 rounded-lg p-6 text-center hover:shadow-lg hover:scale-105 transition-all duration-200 cursor-pointer border-2 border-transparent hover:border-orange-300"
            >
              <div className="w-12 h-12 mx-auto mb-3 bg-orange-200 dark:bg-orange-800 rounded-lg flex items-center justify-center">
                <svg className="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                </svg>
              </div>
              <h3 className="font-medium text-gray-900 dark:text-white text-sm">Expense Tracking</h3>
            </button>

            <button 
              onClick={() => scrollToSection('budget-section')} 
              className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-6 text-center hover:shadow-lg hover:scale-105 transition-all duration-200 cursor-pointer border-2 border-transparent hover:border-blue-300"
            >
              <div className="w-12 h-12 mx-auto mb-3 bg-blue-200 dark:bg-blue-800 rounded-lg flex items-center justify-center">
                <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
              </div>
              <h3 className="font-medium text-gray-900 dark:text-white text-sm">Budget Management</h3>
            </button>

            <button 
              onClick={() => scrollToSection('savings-goals')} 
              className="bg-green-50 dark:bg-green-900/20 rounded-lg p-6 text-center hover:shadow-lg hover:scale-105 transition-all duration-200 cursor-pointer border-2 border-transparent hover:border-green-300"
            >
              <div className="w-12 h-12 mx-auto mb-3 bg-green-200 dark:bg-green-800 rounded-lg flex items-center justify-center">
                <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                </svg>
              </div>
              <h3 className="font-medium text-gray-900 dark:text-white text-sm">Savings Goals</h3>
            </button>

            <button 
              onClick={() => scrollToSection('dashboard-overview')} 
              className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-6 text-center hover:shadow-lg hover:scale-105 transition-all duration-200 cursor-pointer border-2 border-transparent hover:border-purple-300"
            >
              <div className="w-12 h-12 mx-auto mb-3 bg-purple-200 dark:bg-purple-800 rounded-lg flex items-center justify-center">
                <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 8v8m-4-5v5m-4-2v2m-2 4h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
              <h3 className="font-medium text-gray-900 dark:text-white text-sm">Financial Reports</h3>
            </button>

            <button 
              onClick={() => openIncomeModal()} 
              className="bg-yellow-50 dark:bg-yellow-900/20 rounded-lg p-6 text-center hover:shadow-lg hover:scale-105 transition-all duration-200 cursor-pointer border-2 border-transparent hover:border-yellow-300"
            >
              <div className="w-12 h-12 mx-auto mb-3 bg-yellow-200 dark:bg-yellow-800 rounded-lg flex items-center justify-center">
                <svg className="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
              <h3 className="font-medium text-gray-900 dark:text-white text-sm">Income Tracking</h3>
            </button>

            <button 
              onClick={() => scrollToSection('salary-calculator')} 
              className="bg-indigo-50 dark:bg-indigo-900/20 rounded-lg p-6 text-center hover:shadow-lg hover:scale-105 transition-all duration-200 cursor-pointer border-2 border-transparent hover:border-indigo-300"
            >
              <div className="w-12 h-12 mx-auto mb-3 bg-indigo-200 dark:bg-indigo-800 rounded-lg flex items-center justify-center">
                <svg className="w-6 h-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 012-2v16a2 2 0 01-2 2z" />
                </svg>
              </div>
              <h3 className="font-medium text-gray-900 dark:text-white text-sm">Salary Calculator</h3>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div id="salary-calculator">
          <SalaryCalculator
            salary={data.salary}
            onSalaryUpdate={handleSalaryUpdate}
            currency={data.currency || 'USD'}
          />
        </div>

        <div id="dashboard-overview">
          <DashboardOverview data={data} />
        </div>
        
        <div id="expense-tracker">
          <ExpenseTracker
            data={data}
            onAddExpense={handleAddExpense}
            onUpdateExpense={handleUpdateExpense}
            onDeleteExpense={handleDeleteExpense}
          />
        </div>
        
        <div id="budget-section">
          <BudgetSection
            data={data}
            onAddBudget={handleAddBudget}
            onUpdateBudget={handleUpdateBudget}
            onDeleteBudget={handleDeleteBudget}
          />
        </div>
        
        <div id="savings-goals">
          <SavingsGoals
            data={data}
            onAddSavingsGoal={handleAddSavingsGoal}
            onUpdateSavingsGoal={handleUpdateSavingsGoal}
            onDeleteSavingsGoal={handleDeleteSavingsGoal}
            onAddToSavingsGoal={handleAddToSavingsGoal}
          />
        </div>
      </div>

      {/* Developer Credits Section */}
      <footer className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-gray-800 dark:to-gray-900 border-t border-gray-200 dark:border-gray-700 mt-16">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            {/* Developer Info */}
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <img 
                  src={profilePhoto}
                  alt="Aditi Radhakrishnan"
                  className="w-28 h-28 rounded-full object-cover border-4 border-blue-200 dark:border-blue-800"
                />
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                    Developed by Aditi Radhakrishnan
                  </h3>
                  <button 
                    onClick={() => window.open('mailto:aditirad3277@gmail.com?subject=Contact%20about%20WatchMyWallet&body=Hi%20Aditi,%0A%0AI%20found%20your%20WatchMyWallet%20application%20and%20would%20like%20to%20get%20in%20touch.%0A%0APhone:%20(209)%20740-2314%0A%0AThank%20you!', '_blank')}
                    className="mt-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors duration-200 flex items-center gap-2"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                    Contact Me
                  </button>
                </div>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-gray-800 dark:text-gray-200">Technologies Used:</h4>
                <div className="flex flex-wrap gap-2">
                  {[
                    'React 18', 'TypeScript', 'Tailwind CSS', 'Vite', 'Express.js',
                    'Recharts', 'shadcn/ui', 'Drizzle ORM', 'PostgreSQL', 'Wouter'
                  ].map((tech) => (
                    <span 
                      key={tech}
                      className="px-3 py-1 bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-200 rounded-full text-sm font-medium"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Mission Statement */}
            <div className="space-y-4">
              <h4 className="text-xl font-bold text-gray-900 dark:text-white">
                Our Mission
              </h4>
              <div className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-600 shadow-sm">
                <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
                  <strong className="text-indigo-600 dark:text-indigo-400">WatchMyWallet</strong> empowers individuals 
                  to take control of their financial future through intuitive expense tracking, smart budgeting tools, 
                  and goal-oriented savings management. Our comprehensive dashboard transforms complex financial 
                  data into clear, actionable insights, making personal finance management accessible and effective 
                  for everyone.
                </p>
                <div className="mt-4 p-3 bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 rounded-md border-l-4 border-green-400">
                  <p className="text-sm text-gray-600 dark:text-gray-400 font-medium">
                    💡 "Financial freedom begins with understanding where your money goes and planning where it should go next."
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Copyright */}
          <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <p className="text-sm text-gray-500 dark:text-gray-400">
                © 2025 WatchMyWallet. Developed with ❤️ by Aditi Radhakrishnan
              </p>
              <div className="flex items-center gap-4 text-sm text-gray-500 dark:text-gray-400">
                <span>Modern Web Technologies</span>
                <span>•</span>
                <span>Responsive Design</span>
                <span>•</span>
                <span>Full-Stack Development</span>
              </div>
            </div>
          </div>
        </div>
      </footer>

      {/* Income Modal */}
      <IncomeModal
        isOpen={showIncomeModal}
        onClose={() => setShowIncomeModal(false)}
        onAddIncome={handleAddIncome}
      />
    </div>
  );
}
