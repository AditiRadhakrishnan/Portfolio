import { FinanceData, Expense, Budget, SavingsGoal, Income, SalaryInfo } from './types';

const STORAGE_KEY = 'dimedash-finance-data';

const defaultData: FinanceData = {
  expenses: [],
  budgets: [],
  savingsGoals: [],
  income: [],
  salary: undefined,
  currency: 'USD',
  customCategories: [],
};

export const storage = {
  // Get all data
  getData: (): FinanceData => {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      if (data) {
        const parsed = JSON.parse(data);
        return {
          ...defaultData,
          ...parsed,
          currency: parsed.currency || 'USD', // Ensure currency is always set
        };
      }
      return defaultData;
    } catch (error) {
      console.error('Error reading from localStorage:', error);
      return defaultData;
    }
  },

  // Save all data
  saveData: (data: FinanceData): void => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (error) {
      console.error('Error saving to localStorage:', error);
    }
  },

  // Expenses
  addExpense: (expense: Omit<Expense, 'id'>): void => {
    const data = storage.getData();
    const newExpense: Expense = {
      ...expense,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    };
    data.expenses.push(newExpense);
    storage.saveData(data);
  },

  updateExpense: (id: string, updates: Partial<Expense>): void => {
    const data = storage.getData();
    const index = data.expenses.findIndex(e => e.id === id);
    if (index !== -1) {
      data.expenses[index] = { ...data.expenses[index], ...updates };
      storage.saveData(data);
    }
  },

  deleteExpense: (id: string): void => {
    const data = storage.getData();
    data.expenses = data.expenses.filter(e => e.id !== id);
    storage.saveData(data);
  },

  // Budgets
  addBudget: (budget: Omit<Budget, 'id' | 'spent'>): void => {
    const data = storage.getData();
    const existingBudget = data.budgets.find(b => b.category === budget.category);
    
    if (existingBudget) {
      existingBudget.limit = budget.limit;
    } else {
      const newBudget: Budget = {
        ...budget,
        id: Date.now().toString(),
        spent: 0,
        createdAt: new Date().toISOString(),
      };
      data.budgets.push(newBudget);
    }
    storage.saveData(data);
  },

  updateBudget: (id: string, updates: Partial<Budget>): void => {
    const data = storage.getData();
    const index = data.budgets.findIndex(b => b.id === id);
    if (index !== -1) {
      data.budgets[index] = { ...data.budgets[index], ...updates };
      storage.saveData(data);
    }
  },

  deleteBudget: (id: string): void => {
    const data = storage.getData();
    data.budgets = data.budgets.filter(b => b.id !== id);
    storage.saveData(data);
  },

  // Savings Goals
  addSavingsGoal: (goal: Omit<SavingsGoal, 'id' | 'current'>): void => {
    const data = storage.getData();
    const newGoal: SavingsGoal = {
      ...goal,
      id: Date.now().toString(),
      current: 0,
      createdAt: new Date().toISOString(),
    };
    data.savingsGoals.push(newGoal);
    storage.saveData(data);
  },

  updateSavingsGoal: (id: string, updates: Partial<SavingsGoal>): void => {
    const data = storage.getData();
    const index = data.savingsGoals.findIndex(g => g.id === id);
    if (index !== -1) {
      data.savingsGoals[index] = { ...data.savingsGoals[index], ...updates };
      storage.saveData(data);
    }
  },

  deleteSavingsGoal: (id: string): void => {
    const data = storage.getData();
    data.savingsGoals = data.savingsGoals.filter(g => g.id !== id);
    storage.saveData(data);
  },

  addToSavingsGoal: (id: string, amount: number): void => {
    const data = storage.getData();
    const goal = data.savingsGoals.find(g => g.id === id);
    if (goal) {
      goal.current = Math.min(goal.current + amount, goal.target);
      storage.saveData(data);
    }
  },

  // Income
  addIncome: (income: Omit<Income, 'id'>): void => {
    const data = storage.getData();
    const newIncome: Income = {
      ...income,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    };
    data.income.push(newIncome);
    storage.saveData(data);
  },

  updateIncome: (id: string, updates: Partial<Income>): void => {
    const data = storage.getData();
    const index = data.income.findIndex(i => i.id === id);
    if (index !== -1) {
      data.income[index] = { ...data.income[index], ...updates };
      storage.saveData(data);
    }
  },

  deleteIncome: (id: string): void => {
    const data = storage.getData();
    data.income = data.income.filter(i => i.id !== id);
    storage.saveData(data);
  },

  // Update budget spent amounts based on expenses
  updateBudgetSpent: (): void => {
    const data = storage.getData();
    const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM
    
    // Reset all budget spent amounts
    data.budgets.forEach(budget => {
      budget.spent = 0;
    });

    // Calculate spent amounts for current month
    data.expenses.forEach(expense => {
      if (expense.date.startsWith(currentMonth)) {
        const budget = data.budgets.find(b => b.category === expense.category);
        if (budget) {
          budget.spent += expense.amount;
        }
      }
    });

    storage.saveData(data);
  },

  // Salary
  setSalary: (salary: SalaryInfo): void => {
    const data = storage.getData();
    data.salary = salary;
    storage.saveData(data);
  },

  getSalary: (): SalaryInfo | undefined => {
    const data = storage.getData();
    return data.salary;
  },

  deleteSalary: (): void => {
    const data = storage.getData();
    data.salary = undefined;
    storage.saveData(data);
  },

  // Currency
  setCurrency: (currency: string): void => {
    const data = storage.getData();
    data.currency = currency;
    storage.saveData(data);
  },

  getCurrency: (): string => {
    const data = storage.getData();
    return data.currency || 'USD';
  },

  // Custom Categories
  addCustomCategory: (category: string): void => {
    const data = storage.getData();
    if (!data.customCategories) {
      data.customCategories = [];
    }
    if (!data.customCategories.includes(category.toLowerCase())) {
      data.customCategories.push(category.toLowerCase());
      storage.saveData(data);
    }
  },

  getCustomCategories: (): string[] => {
    const data = storage.getData();
    return data.customCategories || [];
  },
};
