import { SUPPORTED_CURRENCIES, type Currency } from './types';

export function getCurrency(code: string): Currency {
  return SUPPORTED_CURRENCIES.find(c => c.code === code) || SUPPORTED_CURRENCIES[0];
}

export function formatCurrency(amount: number, currencyCode: string = 'USD'): string {
  const currency = getCurrency(currencyCode);
  
  // Format based on currency
  if (currencyCode === 'JPY' || currencyCode === 'CNY') {
    // No decimal places for yen currencies
    return `${currency.symbol}${Math.round(amount).toLocaleString()}`;
  } else if (currencyCode === 'INR') {
    // Indian number formatting
    return `${currency.symbol}${amount.toLocaleString('en-IN', { 
      minimumFractionDigits: 2, 
      maximumFractionDigits: 2 
    })}`;
  } else {
    // Standard formatting
    return `${currency.symbol}${amount.toLocaleString(undefined, { 
      minimumFractionDigits: 2, 
      maximumFractionDigits: 2 
    })}`;
  }
}

export function convertCurrency(amount: number, fromCurrency: string, toCurrency: string): number {
  if (fromCurrency === toCurrency) return amount;
  
  const fromRate = getCurrency(fromCurrency).rate;
  const toRate = getCurrency(toCurrency).rate;
  
  // Convert to USD first, then to target currency
  const usdAmount = amount / fromRate;
  return usdAmount * toRate;
}

export function getCurrencySymbol(currencyCode: string): string {
  return getCurrency(currencyCode).symbol;
}