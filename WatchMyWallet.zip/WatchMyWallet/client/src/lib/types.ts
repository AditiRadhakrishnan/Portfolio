export interface FinanceData {
  expenses: Expense[];
  budgets: Budget[];
  savingsGoals: SavingsGoal[];
  income: Income[];
  salary?: SalaryInfo;
  currency?: string;
  customCategories?: string[];
}

export interface SalaryInfo {
  annualSalary: number;
  payFrequency: 'weekly' | 'biweekly' | 'monthly' | 'annual';
  taxRate: number; // as percentage
}

export interface Expense {
  id: string;
  description: string;
  amount: number;
  category: string;
  date: string;
  createdAt?: string;
}

export interface Budget {
  id: string;
  category: string;
  limit: number;
  spent: number;
  createdAt?: string;
}

export interface SavingsGoal {
  id: string;
  name: string;
  description?: string;
  target: number;
  current: number;
  targetDate?: string;
  createdAt?: string;
}

export interface Income {
  id: string;
  amount: number;
  source: string;
  date: string;
  createdAt?: string;
}

export const EXPENSE_CATEGORIES = [
  'groceries',
  'dining',
  'transportation',
  'utilities',
  'entertainment',
  'shopping',
  'healthcare',
  'other',
] as const;

export type ExpenseCategory = typeof EXPENSE_CATEGORIES[number];

export interface Currency {
  code: string;
  name: string;
  symbol: string;
  rate: number; // Exchange rate to USD
}

export const SUPPORTED_CURRENCIES: Currency[] = [
  { code: 'USD', name: 'US Dollar', symbol: '$', rate: 1.0 },
  { code: 'CAD', name: 'Canadian Dollar', symbol: 'C$', rate: 1.35 },
  { code: 'EUR', name: 'Euro', symbol: '€', rate: 0.85 },
  { code: 'GBP', name: 'British Pound', symbol: '£', rate: 0.79 },
  { code: 'INR', name: 'Indian Rupee', symbol: '₹', rate: 83.12 },
  { code: 'MXN', name: 'Mexican Peso', symbol: '$', rate: 17.23 },
  { code: 'JPY', name: 'Japanese Yen', symbol: '¥', rate: 149.50 },
  { code: 'CNY', name: 'Chinese Yuan', symbol: '¥', rate: 7.24 },
  { code: 'AUD', name: 'Australian Dollar', symbol: 'A$', rate: 1.52 },
  { code: 'CHF', name: 'Swiss Franc', symbol: 'CHF', rate: 0.88 },
];
