import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ShoppingCart, Car, Gamepad2, Home, DollarSign, Package, Heart, MoreHorizontal, Plus } from "lucide-react";
import { FinanceData, Budget } from "@/lib/types";
import { BudgetModal } from "./modals/budget-modal";
import { formatCurrency } from "@/lib/currency";

interface BudgetSectionProps {
  data: FinanceData;
  onAddBudget: (budget: Omit<Budget, 'id' | 'spent'>) => void;
  onUpdateBudget: (id: string, updates: Partial<Budget>) => void;
  onDeleteBudget: (id: string) => void;
}

const categoryIcons: Record<string, any> = {
  groceries: ShoppingCart,
  dining: ShoppingCart,
  transportation: Car,
  utilities: Home,
  entertainment: Gamepad2,
  shopping: Package,
  healthcare: Heart,
  other: MoreHorizontal,
};

const categoryColors: Record<string, string> = {
  groceries: 'bg-green-100 text-green-600 dark:bg-green-900 dark:text-green-300',
  dining: 'bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-300',
  transportation: 'bg-purple-100 text-purple-600 dark:bg-purple-900 dark:text-purple-300',
  utilities: 'bg-yellow-100 text-yellow-600 dark:bg-yellow-900 dark:text-yellow-300',
  entertainment: 'bg-pink-100 text-pink-600 dark:bg-pink-900 dark:text-pink-300',
  shopping: 'bg-indigo-100 text-indigo-600 dark:bg-indigo-900 dark:text-indigo-300',
  healthcare: 'bg-red-100 text-red-600 dark:bg-red-900 dark:text-red-300',
  other: 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300',
};

// Function to get category color for budgets, with fallback for custom categories
const getBudgetCategoryColor = (category: string): string => {
  if (categoryColors[category]) {
    return categoryColors[category];
  }
  // Generate a consistent color for custom categories
  const colors = [
    'bg-cyan-100 text-cyan-600 dark:bg-cyan-900 dark:text-cyan-300',
    'bg-emerald-100 text-emerald-600 dark:bg-emerald-900 dark:text-emerald-300',
    'bg-orange-100 text-orange-600 dark:bg-orange-900 dark:text-orange-300',
    'bg-teal-100 text-teal-600 dark:bg-teal-900 dark:text-teal-300',
    'bg-violet-100 text-violet-600 dark:bg-violet-900 dark:text-violet-300',
    'bg-rose-100 text-rose-600 dark:bg-rose-900 dark:text-rose-300',
  ];
  const hash = category.split('').reduce((a, b) => {
    a = ((a << 5) - a) + b.charCodeAt(0);
    return a & a;
  }, 0);
  return colors[Math.abs(hash) % colors.length];
};

export default function BudgetSection({ data, onAddBudget, onUpdateBudget, onDeleteBudget }: BudgetSectionProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBudget, setEditingBudget] = useState<Budget | null>(null);

  const handleEdit = (budget: Budget) => {
    setEditingBudget(budget);
    setIsModalOpen(true);
  };

  const handleSubmit = (budgetData: Omit<Budget, 'id' | 'spent'>) => {
    if (editingBudget) {
      onUpdateBudget(editingBudget.id, budgetData);
    } else {
      onAddBudget(budgetData);
    }
    setIsModalOpen(false);
    setEditingBudget(null);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingBudget(null);
  };

  const getProgressColor = (percentage: number) => {
    if (percentage >= 90) return 'bg-red-600';
    if (percentage >= 75) return 'bg-yellow-600';
    return 'bg-green-600';
  };

  return (
    <section className="mb-8">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-4 sm:mb-0">Monthly Budgets</h2>
        <Button onClick={() => setIsModalOpen(true)} className="bg-primary text-white hover:bg-primary/90">
          <Plus className="w-4 h-4 mr-2" />
          Set Budget
        </Button>
      </div>

      {data.budgets.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {data.budgets.map((budget) => {
            const IconComponent = categoryIcons[budget.category] || DollarSign;
            const percentage = budget.limit > 0 ? (budget.spent / budget.limit) * 100 : 0;
            const remaining = budget.limit - budget.spent;

            return (
              <Card key={budget.id}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center">
                      <div className={`p-2 rounded-lg mr-3 ${getBudgetCategoryColor(budget.category)}`}>
                        <IconComponent className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 dark:text-gray-100">
                          {budget.category.charAt(0).toUpperCase() + budget.category.slice(1)}
                        </h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {formatCurrency(budget.spent, data.currency)} of {formatCurrency(budget.limit, data.currency)}
                        </p>
                      </div>
                    </div>
                    <span className={`text-lg font-bold ${
                      percentage >= 90 ? 'text-red-600' : 
                      percentage >= 75 ? 'text-yellow-600' : 
                      'text-green-600'
                    }`}>
                      {percentage.toFixed(0)}%
                    </span>
                  </div>
                  
                  <Progress 
                    value={Math.min(percentage, 100)} 
                    className="w-full mb-4"
                  />
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      Remaining: {formatCurrency(Math.max(remaining, 0), data.currency)}
                    </span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEdit(budget)}
                      className="text-primary hover:text-primary/80"
                    >
                      Edit
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <Card>
          <CardContent className="text-center py-12">
            <div className="text-gray-500">
              <DollarSign className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p className="text-lg mb-2">No budgets set yet</p>
              <p className="mb-4">Create your first budget to start tracking your spending limits!</p>
              <Button onClick={() => setIsModalOpen(true)} className="bg-primary text-white hover:bg-primary/90">
                Set Your First Budget
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <BudgetModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        onSubmit={handleSubmit}
        budget={editingBudget}
      />
    </section>
  );
}
