import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Target, Calendar, DollarSign, Plus, Pencil } from "lucide-react";
import { FinanceData, SavingsGoal } from "@/lib/types";
import { GoalModal } from "./modals/goal-modal";
import { formatCurrency } from "@/lib/currency";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

interface SavingsGoalsProps {
  data: FinanceData;
  onAddSavingsGoal: (goal: Omit<SavingsGoal, 'id' | 'current'>) => void;
  onUpdateSavingsGoal: (id: string, updates: Partial<SavingsGoal>) => void;
  onDeleteSavingsGoal: (id: string) => void;
  onAddToSavingsGoal: (id: string, amount: number) => void;
}

export default function SavingsGoals({ 
  data, 
  onAddSavingsGoal, 
  onUpdateSavingsGoal, 
  onDeleteSavingsGoal, 
  onAddToSavingsGoal 
}: SavingsGoalsProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState<SavingsGoal | null>(null);
  const [addMoneyGoal, setAddMoneyGoal] = useState<string | null>(null);
  const [addAmount, setAddAmount] = useState('');

  const handleEdit = (goal: SavingsGoal) => {
    setEditingGoal(goal);
    setIsModalOpen(true);
  };

  const handleSubmit = (goalData: Omit<SavingsGoal, 'id' | 'current'>) => {
    if (editingGoal) {
      onUpdateSavingsGoal(editingGoal.id, goalData);
    } else {
      onAddSavingsGoal(goalData);
    }
    setIsModalOpen(false);
    setEditingGoal(null);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingGoal(null);
  };

  const handleAddMoney = () => {
    if (addMoneyGoal && addAmount) {
      const amount = parseFloat(addAmount);
      if (amount > 0) {
        onAddToSavingsGoal(addMoneyGoal, amount);
        setAddMoneyGoal(null);
        setAddAmount('');
      }
    }
  };

  return (
    <section className="mb-8">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-4 sm:mb-0">Savings Goals</h2>
        <Button onClick={() => setIsModalOpen(true)} className="bg-primary text-white hover:bg-primary/90">
          <Plus className="w-4 h-4 mr-2" />
          Add Goal
        </Button>
      </div>

      {data.savingsGoals.length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {data.savingsGoals.map((goal) => {
            const progress = goal.target > 0 ? (goal.current / goal.target) * 100 : 0;
            const isCompleted = progress >= 100;

            return (
              <Card key={goal.id}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">{goal.name}</h3>
                      {goal.description && (
                        <p className="text-sm text-gray-600 dark:text-gray-400">{goal.description}</p>
                      )}
                    </div>
                    <div className="text-right">
                      <p className={`text-2xl font-bold ${
                        isCompleted ? 'text-green-600' : 'text-primary'
                      }`}>
                        {progress.toFixed(0)}%
                      </p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Complete</p>
                    </div>
                  </div>
                  
                  <div className="mb-4">
                    <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400 mb-2">
                      <span>Progress</span>
                      <span>{formatCurrency(goal.current, data.currency)} / {formatCurrency(goal.target, data.currency)}</span>
                    </div>
                    <Progress 
                      value={Math.min(progress, 100)} 
                      className="w-full h-4"
                    />
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                      {goal.targetDate && (
                        <>
                          <Calendar className="w-4 h-4 mr-1" />
                          <span>Target: {new Date(goal.targetDate).toLocaleDateString()}</span>
                        </>
                      )}
                    </div>
                    <div className="flex space-x-2">
                      {!isCompleted && (
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="text-primary hover:text-primary/80"
                            >
                              Add Money
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Add Money to {goal.name}</DialogTitle>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div>
                                <label className="block text-sm font-medium mb-2">Amount to Add</label>
                                <Input
                                  type="number"
                                  step="0.01"
                                  min="0.01"
                                  placeholder="0.00"
                                  value={addAmount}
                                  onChange={(e) => setAddAmount(e.target.value)}
                                />
                              </div>
                              <div className="flex justify-end space-x-2">
                                <Button
                                  variant="outline"
                                  onClick={() => setAddAmount('')}
                                >
                                  Cancel
                                </Button>
                                <Button
                                  onClick={() => {
                                    if (addAmount) {
                                      const amount = parseFloat(addAmount);
                                      if (amount > 0) {
                                        onAddToSavingsGoal(goal.id, amount);
                                        setAddAmount('');
                                      }
                                    }
                                  }}
                                >
                                  Add Money
                                </Button>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEdit(goal)}
                        className="text-gray-500 hover:text-gray-700"
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <Card>
          <CardContent className="text-center py-12">
            <div className="text-gray-500">
              <Target className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p className="text-lg mb-2">No savings goals yet</p>
              <p className="mb-4">Create your first savings goal and start building your financial future!</p>
              <Button onClick={() => setIsModalOpen(true)} className="bg-primary text-white hover:bg-primary/90">
                Create Your First Goal
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <GoalModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        onSubmit={handleSubmit}
        goal={editingGoal}
      />
    </section>
  );
}
