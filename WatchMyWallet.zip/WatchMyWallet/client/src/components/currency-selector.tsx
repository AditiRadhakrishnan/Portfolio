import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { SUPPORTED_CURRENCIES } from '@/lib/types';
import { Globe } from 'lucide-react';

interface CurrencySelectorProps {
  selectedCurrency: string;
  onCurrencyChange: (currency: string) => void;
  size?: 'sm' | 'md' | 'lg';
}

export function CurrencySelector({ selectedCurrency, onCurrencyChange, size = 'md' }: CurrencySelectorProps) {
  const selectedCurrencyData = SUPPORTED_CURRENCIES.find(c => c.code === selectedCurrency);

  return (
    <div className="flex items-center gap-2">
      <Globe className={`text-gray-500 dark:text-gray-400 ${
        size === 'sm' ? 'w-4 h-4' : size === 'lg' ? 'w-6 h-6' : 'w-5 h-5'
      }`} />
      <Select value={selectedCurrency} onValueChange={onCurrencyChange}>
        <SelectTrigger className={`${
          size === 'sm' ? 'w-24 h-8 text-sm' : 
          size === 'lg' ? 'w-32 h-12 text-lg' : 
          'w-28 h-10'
        }`}>
          <SelectValue>
            <span className="flex items-center gap-2">
              <span className="font-medium">{selectedCurrencyData?.symbol}</span>
              <span className="text-sm text-gray-600 dark:text-gray-400">{selectedCurrency}</span>
            </span>
          </SelectValue>
        </SelectTrigger>
        <SelectContent>
          {SUPPORTED_CURRENCIES.map((currency) => (
            <SelectItem key={currency.code} value={currency.code}>
              <div className="flex items-center gap-3">
                <span className="font-medium w-6">{currency.symbol}</span>
                <div className="flex flex-col">
                  <span className="font-medium">{currency.code}</span>
                  <span className="text-xs text-gray-500">{currency.name}</span>
                </div>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}