import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calculator, DollarSign, Calendar, Wallet, PiggyBank } from 'lucide-react';
import type { SalaryInfo, FinanceData } from '../lib/types';
import { formatCurrency } from '../lib/currency';

interface SalaryCalculatorProps {
  salary?: SalaryInfo;
  onSalaryUpdate: (salary: SalaryInfo) => void;
  currency?: string;
}

export function SalaryCalculator({ salary, onSalaryUpdate, currency = 'USD' }: SalaryCalculatorProps) {
  const [showCalculator, setShowCalculator] = useState(false);
  const [formData, setFormData] = useState<SalaryInfo>(
    salary || {
      annualSalary: 0,
      payFrequency: 'monthly',
      taxRate: 25, // Default 25% tax rate
    }
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSalaryUpdate(formData);
    setShowCalculator(false);
  };

  const calculateSpending = () => {
    const { annualSalary, taxRate } = formData;
    const afterTax = annualSalary * (1 - taxRate / 100);
    
    // 50/30/20 rule: 50% needs, 30% wants, 20% savings
    const needs = afterTax * 0.5;
    const wants = afterTax * 0.3;
    const savings = afterTax * 0.2;

    return {
      gross: {
        annual: annualSalary,
        monthly: annualSalary / 12,
        weekly: annualSalary / 52,
        daily: annualSalary / 365,
      },
      net: {
        annual: afterTax,
        monthly: afterTax / 12,
        weekly: afterTax / 52,
        daily: afterTax / 365,
      },
      breakdown: {
        needs: {
          annual: needs,
          monthly: needs / 12,
          weekly: needs / 52,
          daily: needs / 365,
        },
        wants: {
          annual: wants,
          monthly: wants / 12,
          weekly: wants / 52,
          daily: wants / 365,
        },
        savings: {
          annual: savings,
          monthly: savings / 12,
          weekly: savings / 52,
          daily: savings / 365,
        },
      },
    };
  };

  const spending = salary ? calculateSpending() : null;

  return (
    <section className="mb-12">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-3">Salary Calculator</h2>
        <p className="text-gray-600 dark:text-gray-300">
          Calculate how much you can spend based on your income using the 50/30/20 rule
        </p>
      </div>

      {!salary || showCalculator ? (
        <Card className="border-0 shadow-lg mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calculator className="w-5 h-5" />
              {salary ? 'Update Salary Information' : 'Enter Your Salary Information'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="annualSalary">Annual Salary</Label>
                  <Input
                    id="annualSalary"
                    type="number"
                    placeholder="e.g., 75000"
                    value={formData.annualSalary || ''}
                    onChange={(e) =>
                      setFormData({ ...formData, annualSalary: Number(e.target.value) })
                    }
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="taxRate">Tax Rate (%)</Label>
                  <Input
                    id="taxRate"
                    type="number"
                    placeholder="e.g., 25"
                    min="0"
                    max="50"
                    value={formData.taxRate}
                    onChange={(e) =>
                      setFormData({ ...formData, taxRate: Number(e.target.value) })
                    }
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="payFrequency">Pay Frequency</Label>
                  <Select
                    value={formData.payFrequency}
                    onValueChange={(value) =>
                      setFormData({ ...formData, payFrequency: value as SalaryInfo['payFrequency'] })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select frequency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="biweekly">Bi-weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="annual">Annual</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex gap-3">
                <Button type="submit" className="flex-1">
                  Calculate Spending Plan
                </Button>
                {salary && (
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setShowCalculator(false)}
                  >
                    Cancel
                  </Button>
                )}
              </div>
            </form>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-8">
          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20">
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-blue-700 dark:text-blue-300">Gross Salary</p>
                    <p className="text-2xl font-bold text-blue-900 dark:text-blue-100">
                      {formatCurrency(spending?.gross.annual || 0, currency)}
                    </p>
                  </div>
                  <div className="p-3 rounded-full bg-blue-200 dark:bg-blue-800">
                    <DollarSign className="w-5 h-5 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20">
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-green-700 dark:text-green-300">Take Home</p>
                    <p className="text-2xl font-bold text-green-900 dark:text-green-100">
                      {formatCurrency(spending?.net.annual || 0, currency)}
                    </p>
                  </div>
                  <div className="p-3 rounded-full bg-green-200 dark:bg-green-800">
                    <Wallet className="w-5 h-5 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20">
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-purple-700 dark:text-purple-300">Tax Rate</p>
                    <p className="text-2xl font-bold text-purple-900 dark:text-purple-100">
                      {salary.taxRate}%
                    </p>
                  </div>
                  <div className="p-3 rounded-full bg-purple-200 dark:bg-purple-800">
                    <Calculator className="w-5 h-5 text-purple-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="text-center">
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Actions</p>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setShowCalculator(true)}
                  >
                    Update
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* 50/30/20 Breakdown */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <Card className="border-0 shadow-lg bg-gradient-to-br from-red-50 to-red-100 dark:from-red-900/20 dark:to-red-800/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-800 dark:text-red-200">
                  <Calendar className="w-5 h-5" />
                  Needs (50%)
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <p className="text-3xl font-bold text-red-900 dark:text-red-100">
                    {formatCurrency(spending?.breakdown.needs.monthly || 0, currency)}
                  </p>
                  <p className="text-sm text-red-700 dark:text-red-300">per month</p>
                </div>
                <div className="space-y-2 text-sm text-red-800 dark:text-red-200">
                  <div className="flex justify-between">
                    <span>Weekly:</span>
                    <span>{formatCurrency(spending?.breakdown.needs.weekly || 0, currency)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Daily:</span>
                    <span>{formatCurrency(spending?.breakdown.needs.daily || 0, currency)}</span>
                  </div>
                </div>
                <p className="text-xs text-red-600 dark:text-red-400">
                  Rent, utilities, groceries, minimum debt payments
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg bg-gradient-to-br from-yellow-50 to-yellow-100 dark:from-yellow-900/20 dark:to-yellow-800/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-yellow-800 dark:text-yellow-200">
                  <Wallet className="w-5 h-5" />
                  Wants (30%)
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <p className="text-3xl font-bold text-yellow-900 dark:text-yellow-100">
                    {formatCurrency(spending?.breakdown.wants.monthly || 0, currency)}
                  </p>
                  <p className="text-sm text-yellow-700 dark:text-yellow-300">per month</p>
                </div>
                <div className="space-y-2 text-sm text-yellow-800 dark:text-yellow-200">
                  <div className="flex justify-between">
                    <span>Weekly:</span>
                    <span>{formatCurrency(spending?.breakdown.wants.weekly || 0, currency)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Daily:</span>
                    <span>{formatCurrency(spending?.breakdown.wants.daily || 0, currency)}</span>
                  </div>
                </div>
                <p className="text-xs text-yellow-600 dark:text-yellow-400">
                  Dining out, entertainment, hobbies, subscriptions
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-green-800 dark:text-green-200">
                  <PiggyBank className="w-5 h-5" />
                  Savings (20%)
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <p className="text-3xl font-bold text-green-900 dark:text-green-100">
                    {formatCurrency(spending?.breakdown.savings.monthly || 0, currency)}
                  </p>
                  <p className="text-sm text-green-700 dark:text-green-300">per month</p>
                </div>
                <div className="space-y-2 text-sm text-green-800 dark:text-green-200">
                  <div className="flex justify-between">
                    <span>Weekly:</span>
                    <span>{formatCurrency(spending?.breakdown.savings.weekly || 0, currency)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Daily:</span>
                    <span>{formatCurrency(spending?.breakdown.savings.daily || 0, currency)}</span>
                  </div>
                </div>
                <p className="text-xs text-green-600 dark:text-green-400">
                  Emergency fund, retirement, investments
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </section>
  );
}