import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Budget, EXPENSE_CATEGORIES } from "@/lib/types";
import { storage } from "@/lib/storage";

const budgetSchema = z.object({
  category: z.string().min(1, 'Category is required'),
  limit: z.number().min(0.01, 'Budget limit must be greater than 0'),
});

type BudgetFormData = z.infer<typeof budgetSchema>;

interface BudgetModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (budget: Omit<Budget, 'id' | 'spent'>) => void;
  budget?: Budget | null;
}

export function BudgetModal({ isOpen, onClose, onSubmit, budget }: BudgetModalProps) {
  const [showCustomCategory, setShowCustomCategory] = useState(false);
  const [customCategory, setCustomCategory] = useState('');
  const [customCategories, setCustomCategories] = useState<string[]>([]);

  const form = useForm<BudgetFormData>({
    resolver: zodResolver(budgetSchema),
    defaultValues: {
      category: '',
      limit: 0,
    },
  });

  useEffect(() => {
    // Load custom categories when modal opens
    if (isOpen) {
      setCustomCategories(storage.getCustomCategories());
    }
  }, [isOpen]);

  useEffect(() => {
    if (budget) {
      form.reset({
        category: budget.category as any,
        limit: budget.limit,
      });
    } else {
      form.reset({
        category: undefined,
        limit: 0,
      });
    }
  }, [budget, form]);

  const handleSubmit = (data: BudgetFormData) => {
    let finalCategory = data.category;
    
    // If custom category is being used, save it and use it
    if (showCustomCategory && customCategory.trim()) {
      finalCategory = customCategory.trim().toLowerCase();
      storage.addCustomCategory(finalCategory);
    }

    onSubmit({
      category: finalCategory,
      limit: data.limit,
    });
    
    // Reset form and custom category state
    form.reset();
    setShowCustomCategory(false);
    setCustomCategory('');
  };

  const handleClose = () => {
    form.reset();
    setShowCustomCategory(false);
    setCustomCategory('');
    onClose();
  };

  const handleCategoryChange = (value: string) => {
    if (value === 'other') {
      setShowCustomCategory(true);
      form.setValue('category', 'other');
    } else {
      setShowCustomCategory(false);
      setCustomCategory('');
      form.setValue('category', value);
    }
  };

  // Get all available categories (predefined + custom)
  const allCategories = [
    ...EXPENSE_CATEGORIES.filter(cat => cat !== 'other'),
    ...customCategories,
    'other'
  ];

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{budget ? 'Edit Budget' : 'Set Budget'}</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select onValueChange={handleCategoryChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {allCategories.map(category => (
                        <SelectItem key={category} value={category}>
                          {category.charAt(0).toUpperCase() + category.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {showCustomCategory && (
              <div className="space-y-2">
                <Label htmlFor="customCategory">Custom Category Name</Label>
                <Input
                  id="customCategory"
                  type="text"
                  placeholder="e.g., Rent, EMI, Loan"
                  value={customCategory}
                  onChange={(e) => setCustomCategory(e.target.value)}
                  className="w-full"
                />
                <p className="text-sm text-gray-500">Enter a custom category name for your budget</p>
              </div>
            )}

            <FormField
              control={form.control}
              name="limit"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Monthly Budget Limit</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      step="0.01"
                      min="0.01"
                      placeholder="0.00"
                      {...field}
                      onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end space-x-2 pt-4">
              <Button type="button" variant="outline" onClick={handleClose}>
                Cancel
              </Button>
              <Button type="submit">
                {budget ? 'Update Budget' : 'Set Budget'}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
