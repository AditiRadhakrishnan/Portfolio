import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Expense, EXPENSE_CATEGORIES } from "@/lib/types";
import { storage } from "@/lib/storage";

const expenseSchema = z.object({
  description: z.string().min(1, 'Description is required'),
  amount: z.number().min(0.01, 'Amount must be greater than 0'),
  category: z.string().min(1, 'Category is required'),
  date: z.string().min(1, 'Date is required'),
});

type ExpenseFormData = z.infer<typeof expenseSchema>;

interface ExpenseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (expense: Omit<Expense, 'id'>) => void;
  expense?: Expense | null;
}

export function ExpenseModal({ isOpen, onClose, onSubmit, expense }: ExpenseModalProps) {
  const [showCustomCategory, setShowCustomCategory] = useState(false);
  const [customCategory, setCustomCategory] = useState('');
  const [customCategories, setCustomCategories] = useState<string[]>([]);

  const form = useForm<ExpenseFormData>({
    resolver: zodResolver(expenseSchema),
    defaultValues: {
      description: '',
      amount: 0,
      category: '',
      date: new Date().toISOString().split('T')[0],
    },
  });

  useEffect(() => {
    // Load custom categories when modal opens
    if (isOpen) {
      setCustomCategories(storage.getCustomCategories());
    }
  }, [isOpen]);

  useEffect(() => {
    if (expense) {
      form.reset({
        description: expense.description,
        amount: expense.amount,
        category: expense.category as any,
        date: expense.date,
      });
    } else {
      form.reset({
        description: '',
        amount: 0,
        category: undefined,
        date: new Date().toISOString().split('T')[0],
      });
    }
  }, [expense, form]);

  const handleSubmit = (data: ExpenseFormData) => {
    let finalCategory = data.category;
    
    // If custom category is being used, save it and use it
    if (showCustomCategory && customCategory.trim()) {
      finalCategory = customCategory.trim().toLowerCase();
      storage.addCustomCategory(finalCategory);
    }

    onSubmit({
      description: data.description,
      amount: data.amount,
      category: finalCategory,
      date: data.date,
    });
    
    // Reset form and custom category state
    form.reset();
    setShowCustomCategory(false);
    setCustomCategory('');
  };

  const handleClose = () => {
    form.reset();
    setShowCustomCategory(false);
    setCustomCategory('');
    onClose();
  };

  const handleCategoryChange = (value: string) => {
    if (value === 'other') {
      setShowCustomCategory(true);
      form.setValue('category', 'other');
    } else {
      setShowCustomCategory(false);
      setCustomCategory('');
      form.setValue('category', value);
    }
  };

  // Get all available categories (predefined + custom)
  const allCategories = [
    ...EXPENSE_CATEGORIES.filter(cat => cat !== 'other'),
    ...customCategories,
    'other'
  ];

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{expense ? 'Edit Expense' : 'Add New Expense'}</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Input placeholder="What did you spend on?" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Amount</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      step="0.01"
                      min="0.01"
                      placeholder="0.00"
                      {...field}
                      onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select onValueChange={handleCategoryChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {allCategories.map(category => (
                        <SelectItem key={category} value={category}>
                          {category.charAt(0).toUpperCase() + category.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {showCustomCategory && (
              <div className="space-y-2">
                <Label htmlFor="customCategory">Custom Category Name</Label>
                <Input
                  id="customCategory"
                  type="text"
                  placeholder="e.g., Rent, EMI, Loan"
                  value={customCategory}
                  onChange={(e) => setCustomCategory(e.target.value)}
                  className="w-full"
                />
                <p className="text-sm text-gray-500">Enter a custom category name for your expense</p>
              </div>
            )}

            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Date</FormLabel>
                  <FormControl>
                    <Input type="date" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end space-x-2 pt-4">
              <Button type="button" variant="outline" onClick={handleClose}>
                Cancel
              </Button>
              <Button type="submit">
                {expense ? 'Update Expense' : 'Add Expense'}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
