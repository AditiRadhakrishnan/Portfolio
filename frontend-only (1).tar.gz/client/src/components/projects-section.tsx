import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ExternalLink, Github, Award, DollarSign, Gamepad2, GraduationCap, Shield, Loader, Sparkles, Play, Users, Target, TrendingUp, Clock } from "lucide-react";
import { useState } from "react";

interface ProjectCardProps {
  title: string;
  description: string;
  image: string;
  imageAlt: string;
  badge: {
    text: string;
    emoji: string;
    color: string;
  };
  technologies: Array<{
    name: string;
    color: string;
  }>;
  liveUrl?: string;
  githubUrl?: string;
  category: string;
  detailedInfo?: {
    overview: string;
    keyMetrics: Array<{
      label: string;
      value: string;
      icon: React.ReactNode;
    }>;
    modules: Array<{
      title: string;
      content: string;
      impact: string;
    }>;
    achievements: string[];
  };
}

function ProjectCard({ 
  title, 
  description, 
  image, 
  imageAlt, 
  badge, 
  technologies, 
  liveUrl, 
  githubUrl, 
  category,
  detailedInfo
}: ProjectCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      whileHover={{ scale: 1.02, rotateY: 5 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      className="group"
    >
      <Card className="overflow-hidden border border-border shadow-sm hover:shadow-2xl transition-all h-full relative mx-2 sm:mx-0">
        <div className="h-40 sm:h-48 relative overflow-hidden">
          <motion.img 
            src={image} 
            alt={imageAlt}
            className="w-full h-full object-cover transition-transform duration-500"
            whileHover={{ scale: 1.1 }}
          />
          <motion.div 
            className="absolute inset-0 bg-gradient-to-br opacity-50" 
            style={{ 
              backgroundImage: `linear-gradient(45deg, ${badge.color}20, ${badge.color}40)` 
            }}
            animate={{
              opacity: isHovered ? 0.7 : 0.5
            }}
          />
          <motion.div
            className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"
            initial={{ opacity: 0 }}
            animate={{ opacity: isHovered ? 1 : 0 }}
            transition={{ duration: 0.3 }}
          />
          
          {/* Animated badge */}
          <motion.div 
            className="absolute top-4 right-4"
            whileHover={{ scale: 1.1, rotate: 5 }}
          >
            <Badge className={`${badge.color} text-white shadow-lg`}>
              {badge.emoji} {badge.text}
            </Badge>
          </motion.div>
          
          {/* Preview overlay on hover */}
          <motion.div
            className="absolute inset-0 flex items-center justify-center"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ 
              opacity: isHovered ? 1 : 0,
              scale: isHovered ? 1 : 0.8
            }}
            transition={{ duration: 0.3 }}
          >
            <div className="bg-white/90 dark:bg-black/90 backdrop-blur-sm rounded-lg p-4 text-center">
              <h4 className="font-bold text-lg mb-2">{category}</h4>
            </div>
          </motion.div>
        </div>
        
        <CardContent className="p-4 sm:p-6 flex flex-col h-[calc(100%-10rem)] sm:h-[calc(100%-12rem)]">
          <h3 className="text-lg sm:text-xl font-semibold mb-2 sm:mb-3" data-testid={`project-title-${title.toLowerCase().replace(/\s+/g, '-')}`}>
            {title}
          </h3>
          <p className="text-muted-foreground mb-3 sm:mb-4 text-xs sm:text-sm flex-grow" data-testid={`project-description-${title.toLowerCase().replace(/\s+/g, '-')}`}>
            {description}
          </p>
          
          <div className="flex flex-wrap gap-2 mb-4" data-testid={`project-technologies-${title.toLowerCase().replace(/\s+/g, '-')}`}>
            {technologies.map((tech) => (
              <Badge 
                key={tech.name}
                variant="secondary" 
                className={`text-xs ${tech.color} px-2 py-1`}
              >
                {tech.name}
              </Badge>
            ))}
          </div>
          
          <div className="flex items-center justify-between mt-auto">
            <div className="flex gap-2">
              {liveUrl && (
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => window.open(liveUrl, "_blank")}
                    data-testid={`button-live-${title.toLowerCase().replace(/\s+/g, '-')}`}
                    className="group relative overflow-hidden"
                  >
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-accent/20 to-chart-2/20"
                      initial={{ x: "-100%" }}
                      whileHover={{ x: "100%" }}
                      transition={{ duration: 0.5 }}
                    />
                    <Play className="w-3 h-3 mr-1 relative z-10" />
                    <span className="relative z-10">Live</span>
                    <ExternalLink className="w-3 h-3 ml-1 relative z-10" />
                  </Button>
                </motion.div>
              )}
              {githubUrl && (
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => window.open(githubUrl, "_blank")}
                    data-testid={`button-github-${title.toLowerCase().replace(/\s+/g, '-')}`}
                    className="group relative overflow-hidden"
                  >
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-chart-2/20 to-accent/20"
                      initial={{ x: "-100%" }}
                      whileHover={{ x: "100%" }}
                      transition={{ duration: 0.5 }}
                    />
                    <Github className="w-3 h-3 mr-1 relative z-10" />
                    <span className="relative z-10">Code</span>
                  </Button>
                </motion.div>
              )}
              {!liveUrl && !githubUrl && !detailedInfo && (
                <Button
                  variant="ghost"
                  size="sm"
                  disabled
                  data-testid={`button-view-${title.toLowerCase().replace(/\s+/g, '-')}`}
                  className="relative"
                >
                  <Sparkles className="w-3 h-3 mr-1" />
                  Coming Soon
                </Button>
              )}
              {detailedInfo && (
                <Dialog>
                  <DialogTrigger asChild>
                    <motion.div
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <Button
                        variant="ghost"
                        size="sm"
                        data-testid={`button-details-${title.toLowerCase().replace(/\s+/g, '-')}`}
                        className="group relative overflow-hidden"
                      >
                        <motion.div
                          className="absolute inset-0 bg-gradient-to-r from-destructive/20 to-chart-1/20"
                          initial={{ x: "-100%" }}
                          whileHover={{ x: "100%" }}
                          transition={{ duration: 0.5 }}
                        />
                        <Shield className="w-3 h-3 mr-1 relative z-10" />
                        <span className="relative z-10">Details</span>
                      </Button>
                    </motion.div>
                  </DialogTrigger>
                  <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle className="flex items-center gap-2 text-xl">
                        {badge.emoji} {title}
                      </DialogTitle>
                    </DialogHeader>
                    
                    <div className="space-y-6">
                      {/* Overview */}
                      <div>
                        <h3 className="font-semibold text-lg mb-2">Project Overview</h3>
                        <p className="text-muted-foreground leading-relaxed">{detailedInfo.overview}</p>
                      </div>

                      {/* Key Metrics */}
                      <div>
                        <h3 className="font-semibold text-lg mb-4">Key Metrics & Impact</h3>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          {detailedInfo.keyMetrics.map((metric, index) => (
                            <div key={index} className="bg-muted/50 rounded-lg p-4 text-center">
                              <div className="flex justify-center mb-2 text-accent">
                                {metric.icon}
                              </div>
                              <div className="text-2xl font-bold text-accent">{metric.value}</div>
                              <div className="text-sm text-muted-foreground">{metric.label}</div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Modules */}
                      <div>
                        <h3 className="font-semibold text-lg mb-4">Workshop Modules</h3>
                        <div className="space-y-4">
                          {detailedInfo.modules.map((module, index) => (
                            <div key={index} className="border border-border rounded-lg p-4">
                              <h4 className="font-medium text-base mb-2">{module.title}</h4>
                              <p className="text-sm text-muted-foreground mb-2">{module.content}</p>
                              <div className="bg-chart-2/10 text-chart-2 text-xs px-2 py-1 rounded-md inline-block">
                                📊 {module.impact}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Achievements */}
                      <div>
                        <h3 className="font-semibold text-lg mb-4">Key Achievements</h3>
                        <div className="space-y-2">
                          {detailedInfo.achievements.map((achievement, index) => (
                            <div key={index} className="flex items-start gap-2">
                              <div className="w-2 h-2 bg-accent rounded-full mt-2 flex-shrink-0"></div>
                              <p className="text-sm">{achievement}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function ProjectsSection() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  const projects = [
    {
      title: "FindMyPaw Platform",
      description: "Revolutionary web app connecting lost pets with their families using React, TypeScript, and Google Maps API. Replaced traditional paper flyers with a centralized digital solution.",
      image: "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      imageAlt: "Happy rescued dogs in an animal shelter environment with adoption focus",
      badge: { text: "Featured", emoji: "🏆", color: "bg-chart-2" },
      technologies: [
        { name: "React", color: "bg-accent/10 text-accent" },
        { name: "TypeScript", color: "bg-chart-2/10 text-chart-2" },
        { name: "AWS", color: "bg-chart-4/10 text-chart-4" },
        { name: "Maps API", color: "bg-chart-1/10 text-chart-1" },
      ],
      liveUrl: "https://findmypaw.org",
      category: "Web Application",
    },
    {
      title: "WatchMyWallet",
      description: "Personal finance tracking application helping users manage budgets and expenses. Features interactive dashboards and spending analytics.",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      imageAlt: "Financial data visualization charts and graphs",
      badge: { text: "Active", emoji: "💰", color: "bg-chart-4" },
      technologies: [
        { name: "React", color: "bg-accent/10 text-accent" },
        { name: "Python", color: "bg-chart-2/10 text-chart-2" },
        { name: "Analytics", color: "bg-chart-4/10 text-chart-4" },
      ],
      liveUrl: "https://watchmywallet.org",
      category: "Finance App",
    },
    {
      title: "Kids' Learning Portal",
      description: "Interactive educational website for temple children featuring cultural games and activities. Increased online engagement by 25% and educational participation by 30%.",
      image: "https://images.unsplash.com/photo-1562774053-701939374585?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      imageAlt: "University campus with students studying outdoors",
      badge: { text: "Cultural", emoji: "🏛️", color: "bg-chart-1" },
      technologies: [
        { name: "React", color: "bg-accent/10 text-accent" },
        { name: "Education", color: "bg-chart-2/10 text-chart-2" },
        { name: "AWS", color: "bg-chart-4/10 text-chart-4" },
      ],
      liveUrl: "https://www.sanatanmandirsanbruno.com/",
      category: "Educational Platform",
    },
    {
      title: "Cybersecurity Awareness Workshop",
      description: "Led comprehensive cybersecurity education initiative reaching 200+ students. Developed interactive modules covering phishing, password security, and social engineering. Achieved 85% completion rate and 40% improvement in security assessment scores.",
      image: "https://images.unsplash.com/photo-1563986768609-322da13575f3?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      imageAlt: "Cybersecurity concepts with digital lock and security",
      badge: { text: "Security", emoji: "🔒", color: "bg-destructive" },
      technologies: [
        { name: "Security Awareness", color: "bg-destructive/10 text-destructive" },
        { name: "Training Design", color: "bg-chart-2/10 text-chart-2" },
        { name: "Data Analysis", color: "bg-chart-4/10 text-chart-4" },
        { name: "Presentation", color: "bg-chart-1/10 text-chart-1" },
      ],
      category: "Educational Campaign",
      detailedInfo: {
        overview: "Designed and delivered a comprehensive cybersecurity awareness program focused on protecting students from digital threats. The workshop combined interactive presentations, hands-on exercises, and real-world case studies to build practical security skills.",
        keyMetrics: [
          { label: "Students Reached", value: "200+", icon: <Users className="w-4 h-4" /> },
          { label: "Completion Rate", value: "85%", icon: <Target className="w-4 h-4" /> },
          { label: "Score Improvement", value: "40%", icon: <TrendingUp className="w-4 h-4" /> },
          { label: "Workshop Duration", value: "3 Hours", icon: <Clock className="w-4 h-4" /> }
        ],
        modules: [
          {
            title: "Phishing Detection & Prevention",
            content: "Interactive email analysis exercises with 95% accuracy improvement in identifying malicious emails",
            impact: "78% reduction in reported phishing incidents among participants"
          },
          {
            title: "Password Security & Management",
            content: "Hands-on training with password managers and multi-factor authentication setup",
            impact: "92% of participants implemented stronger password policies"
          },
          {
            title: "Social Engineering Awareness",
            content: "Role-playing scenarios and case study analysis of real-world attacks",
            impact: "87% improvement in recognizing social engineering tactics"
          },
          {
            title: "Secure Browsing & Wi-Fi Safety",
            content: "Practical demonstrations of VPNs, HTTPS verification, and public Wi-Fi risks",
            impact: "83% adoption of secure browsing practices"
          }
        ],
        achievements: [
          "Developed custom curriculum based on latest threat intelligence",
          "Created interactive assessment tools with immediate feedback",
          "Established pre/post workshop testing framework",
          "Collaborated with campus IT security team for real-world examples",
          "Received 4.8/5 average satisfaction rating from participants"
        ]
      }
    },
    {
      title: "Anagram Game",
      description: "Interactive word puzzle game where players unscramble letters to form valid words. Features multiple difficulty levels, scoring system, and engaging animations for an entertaining educational experience.",
      image: "https://images.unsplash.com/photo-1606092195730-5d7b9af1efc5?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      imageAlt: "Word game interface with scattered letters and puzzle elements",
      badge: { text: "Game", emoji: "🎮", color: "bg-chart-5" },
      technologies: [
        { name: "JavaScript", color: "bg-yellow-100 text-yellow-800" },
        { name: "HTML5", color: "bg-orange-100 text-orange-800" },
        { name: "CSS3", color: "bg-blue-100 text-blue-800" },
        { name: "Game Logic", color: "bg-purple-100 text-purple-800" },
      ],
      liveUrl: "https://aditi-anagram-game.example.com",
      category: "Interactive Game",
    },
    {
      title: "Next Epic Quest",
      description: "Something amazing is brewing... Stay tuned for the next innovative project.",
      image: "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      imageAlt: "Modern workspace with laptop and coffee showing work in progress",
      badge: { text: "In Progress", emoji: "🚧", color: "bg-muted" },
      technologies: [
        { name: "TBD", color: "bg-muted/10 text-muted-foreground" },
        { name: "Innovation", color: "bg-muted/10 text-muted-foreground" },
        { name: "Impact", color: "bg-muted/10 text-muted-foreground" },
      ],
      category: "Coming Soon",
    },
  ];

  return (
    <section id="projects" className="py-12 sm:py-20 bg-secondary/30" data-testid="projects-section">
      <div className="max-w-6xl mx-auto px-3 sm:px-4">
        <motion.div 
          className="text-center mb-8 sm:mb-16"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
        >
          <motion.h2 
            className="text-2xl sm:text-3xl md:text-4xl font-bold mb-3 sm:mb-4"
            variants={itemVariants}
            data-testid="projects-title"
          >
            Quest Completions
          </motion.h2>
          <motion.p 
            className="text-muted-foreground text-lg"
            variants={itemVariants}
            data-testid="projects-subtitle"
          >
            Epic projects that shaped my journey
          </motion.p>
        </motion.div>

        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
        >
          {projects.map((project, index) => (
            <motion.div key={project.title} variants={itemVariants}>
              <ProjectCard {...project} />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
