import { motion, useScroll, useTransform } from "framer-motion";
import { useState, useRef } from "react";
import { Camera, MapPin, Calendar } from "lucide-react";
import photo1 from "@assets/IMG_4587_1756927842582.jpg";
import photo2 from "@assets/IMG_4590_1756928494729.jpg";

const photos = [
  {
    src: photo1,
    alt: "Aditi at UC Berkeley campus with beautiful city view",
    title: "Berkeley Views",
    location: "UC Berkeley Campus",
    date: "2024",
    description: "Enjoying the stunning panoramic views from the Berkeley campus, overlooking the beautiful Bay Area landscape."
  },
  {
    src: photo2,
    alt: "Aditi in graduation setting with 2024 banner",
    title: "Achievement Moment",
    location: "Graduation Ceremony",
    date: "2024",
    description: "Celebrating academic milestones and achievements in a memorable graduation setting."
  }
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.3,
      delayChildren: 0.2
    }
  }
};

const photoVariants = {
  hidden: { 
    opacity: 0, 
    y: 60,
    scale: 0.8 
  },
  visible: { 
    opacity: 1, 
    y: 0,
    scale: 1,
    transition: { 
      duration: 0.8,
      ease: "easeOut"
    }
  }
};

function PhotoCard({ photo, index }: { photo: typeof photos[0], index: number }) {
  const [isHovered, setIsHovered] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);
  
  const { scrollYProgress } = useScroll({
    target: cardRef,
    offset: ["start end", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], [100, -100]);
  const rotateX = useTransform(scrollYProgress, [0, 0.5, 1], [15, 0, -15]);

  return (
    <motion.div
      ref={cardRef}
      variants={photoVariants}
      className={`relative ${index % 2 === 0 ? 'md:mr-8' : 'md:ml-8'}`}
      style={{ y }}
      data-testid={`photo-card-${index}`}
    >
      <motion.div
        className="group relative overflow-hidden rounded-3xl shadow-2xl"
        style={{ rotateX }}
        onHoverStart={() => setIsHovered(true)}
        onHoverEnd={() => setIsHovered(false)}
        whileHover={{ 
          scale: 1.02,
          rotateY: index % 2 === 0 ? 5 : -5,
          transition: { duration: 0.4 }
        }}
      >
        {/* Main Image */}
        <div className="relative aspect-[4/5] overflow-hidden bg-gradient-to-br from-accent/10 to-chart-2/10">
          <motion.img
            src={photo.src}
            alt={photo.alt}
            className="w-full h-full object-cover"
            initial={{ scale: 1.2 }}
            animate={{ scale: isHovered ? 1.1 : 1 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
          />
          
          {/* Gradient Overlay */}
          <motion.div
            className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent"
            initial={{ opacity: 0.3 }}
            animate={{ opacity: isHovered ? 0.6 : 0.3 }}
            transition={{ duration: 0.3 }}
          />

          {/* Floating Elements */}
          <motion.div
            className="absolute top-4 right-4 bg-white/20 backdrop-blur-sm rounded-full p-2"
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ delay: 0.5, duration: 0.5 }}
          >
            <Camera className="w-5 h-5 text-white" />
          </motion.div>

          {/* Content Overlay */}
          <motion.div
            className="absolute bottom-0 left-0 right-0 p-6 text-white"
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.6 }}
          >
            <motion.h3 
              className="text-2xl font-bold mb-2"
              data-testid={`photo-title-${index}`}
            >
              {photo.title}
            </motion.h3>
            
            <motion.div className="flex items-center gap-4 mb-3 text-sm opacity-90">
              <div className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                <span data-testid={`photo-location-${index}`}>{photo.location}</span>
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                <span data-testid={`photo-date-${index}`}>{photo.date}</span>
              </div>
            </motion.div>

            <motion.p 
              className="text-sm leading-relaxed opacity-90"
              initial={{ opacity: 0 }}
              animate={{ opacity: isHovered ? 1 : 0.7 }}
              transition={{ duration: 0.3 }}
              data-testid={`photo-description-${index}`}
            >
              {photo.description}
            </motion.p>
          </motion.div>

          {/* Decorative Border */}
          <motion.div
            className="absolute inset-0 border-2 border-white/20 rounded-3xl"
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ 
              scale: isHovered ? 1.02 : 1, 
              opacity: isHovered ? 1 : 0 
            }}
            transition={{ duration: 0.3 }}
          />
        </div>

        {/* Glow Effect */}
        <motion.div
          className="absolute -inset-1 bg-gradient-to-r from-accent/20 to-chart-2/20 rounded-3xl blur-xl -z-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: isHovered ? 1 : 0 }}
          transition={{ duration: 0.3 }}
        />
      </motion.div>
    </motion.div>
  );
}

export default function PersonalShowcase() {
  const containerRef = useRef<HTMLDivElement>(null);
  
  return (
    <section ref={containerRef} className="py-20 px-4 relative overflow-hidden" data-testid="personal-showcase-section">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-gradient-to-br from-accent/5 to-chart-2/5" />
      <motion.div
        className="absolute top-20 left-10 w-32 h-32 bg-accent/10 rounded-full blur-3xl"
        animate={{ 
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.5, 0.3] 
        }}
        transition={{ 
          duration: 4, 
          repeat: Infinity,
          ease: "easeInOut" 
        }}
      />
      <motion.div
        className="absolute bottom-20 right-10 w-40 h-40 bg-chart-2/10 rounded-full blur-3xl"
        animate={{ 
          scale: [1.2, 1, 1.2],
          opacity: [0.2, 0.4, 0.2] 
        }}
        transition={{ 
          duration: 5, 
          repeat: Infinity,
          ease: "easeInOut",
          delay: 1 
        }}
      />

      <div className="container mx-auto max-w-6xl relative z-10">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <motion.h2 
            className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-accent to-chart-2 bg-clip-text text-transparent"
            data-testid="showcase-title"
          >
            Life at Berkeley
          </motion.h2>
          <motion.p 
            className="text-muted-foreground max-w-2xl mx-auto text-lg"
            data-testid="showcase-subtitle"
          >
            Capturing moments of growth, achievement, and the incredible journey through UC Berkeley
          </motion.p>
        </motion.div>

        <motion.div
          className="grid md:grid-cols-2 gap-12 items-start"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
        >
          {photos.map((photo, index) => (
            <PhotoCard key={index} photo={photo} index={index} />
          ))}
        </motion.div>

        {/* Decorative Quote */}
        <motion.div
          className="text-center mt-20"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.5 }}
        >
          <motion.blockquote 
            className="text-lg italic text-muted-foreground max-w-2xl mx-auto"
            data-testid="showcase-quote"
          >
            "Every moment is a step forward in the journey of learning, growing, and making a difference."
          </motion.blockquote>
        </motion.div>
      </div>
    </section>
  );
}