import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Code, Globe, TrendingUp, Github, Database, Cloud, FileCode, BarChart3, MapPin, Info } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { SkillModal } from "./skill-modal";

interface SkillBarProps {
  name: string;
  percentage: number;
  color: string;
  delay?: number;
}

function SkillBar({ name, percentage, color, delay = 0 }: SkillBarProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => setIsVisible(true), delay);
        }
      },
      { threshold: 0.3 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [delay]);

  const skillData = {
    Java: {
      category: "Programming Language",
      description: "Object-oriented programming language used for enterprise applications, Android development, and large-scale systems. Strong foundation in data structures and algorithms.",
      experience: "3+ years of experience through academic projects and personal development",
      projects: ["Anagrams Game", "Data Structures Projects", "OOP Coursework"],
      achievements: ["4.0 GPA in Java coursework", "Complex algorithm implementation", "Clean code practices"],
      learningPath: ["Basic syntax and OOP concepts", "Data structures and algorithms", "Advanced Java features", "Performance optimization"]
    },
    Python: {
      category: "Programming Language", 
      description: "Versatile programming language for data science, web development, and automation. Extensive use in data analysis and backend development.",
      experience: "2+ years focused on data science and web development",
      projects: ["FindMyPaw Backend", "Data Analysis Scripts", "Automation Tools"],
      achievements: ["Data science implementations", "Web scraping expertise", "Machine learning foundations"],
      learningPath: ["Python fundamentals", "Data science libraries", "Web frameworks", "Advanced data analysis"]
    },
    TypeScript: {
      category: "Programming Language",
      description: "Strongly-typed superset of JavaScript providing better development experience and code reliability for large applications.",
      experience: "2+ years in modern web development",
      projects: ["FindMyPaw Platform", "WatchMyWallet", "Interactive Portfolio"],
      achievements: ["Type-safe applications", "React expertise", "Full-stack development"],
      learningPath: ["JavaScript mastery", "TypeScript fundamentals", "React integration", "Advanced type systems"]
    },
    SQL: {
      category: "Database Technology",
      description: "Structured Query Language for database management and data analysis. Essential for backend development and data science.",
      experience: "2+ years in academic and project contexts",
      projects: ["Database design projects", "Data analysis queries", "Backend integrations"],
      achievements: ["Complex query optimization", "Database design", "Data modeling"],
      learningPath: ["Basic queries", "Advanced joins", "Database design", "Performance tuning"]
    },
    React: {
      category: "Frontend Framework",
      description: "Modern JavaScript library for building user interfaces with component-based architecture and powerful state management.",
      experience: "2+ years building interactive web applications",
      projects: ["FindMyPaw Platform", "Kids' Learning Portal", "Interactive Portfolio"],
      achievements: ["Component architecture", "State management", "User experience design"],
      learningPath: ["JavaScript fundamentals", "React basics", "Advanced patterns", "Performance optimization"]
    },
    "HTML/CSS": {
      category: "Web Technologies",
      description: "Foundation of web development with semantic markup and modern styling techniques including responsive design.",
      experience: "3+ years creating responsive web interfaces",
      projects: ["All web projects", "Responsive designs", "Accessibility implementations"],
      achievements: ["Semantic HTML", "Responsive design", "CSS animations"],
      learningPath: ["HTML fundamentals", "CSS styling", "Responsive design", "Modern CSS features"]
    },
    AWS: {
      category: "Cloud Platform",
      description: "Amazon Web Services for cloud hosting, storage, and deployment of web applications with scalable infrastructure.",
      experience: "1+ year deploying and managing web applications",
      projects: ["FindMyPaw deployment", "S3 hosting", "Amplify deployments"],
      achievements: ["Production deployments", "Scalable hosting", "Cloud architecture"],
      learningPath: ["Cloud fundamentals", "AWS services", "Deployment strategies", "Infrastructure management"]
    },
    APIs: {
      category: "Integration Technology",
      description: "Application Programming Interfaces for connecting different services and building integrated applications.",
      experience: "2+ years integrating various APIs",
      projects: ["Google Maps integration", "Third-party services", "RESTful APIs"],
      achievements: ["API design", "Integration expertise", "Data synchronization"],
      learningPath: ["HTTP fundamentals", "REST principles", "API design", "Advanced integrations"]
    }
  };

  const currentSkill = skillData[name as keyof typeof skillData] || {
    category: "Technology",
    description: "A valuable skill in the technology stack.",
    experience: "Experience gained through various projects",
    projects: ["Multiple projects"],
    achievements: ["Practical application"],
    learningPath: ["Continuous learning"]
  };

  return (
    <>
      <motion.div 
        ref={ref} 
        className="skill-item cursor-pointer group" 
        data-testid={`skill-${name.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}
        whileHover={{ scale: 1.02 }}
        onClick={() => setShowModal(true)}
      >
        <div className="flex justify-between mb-2 items-center">
          <span className="text-sm font-medium group-hover:text-accent transition-colors">{name}</span>
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">{percentage}%</span>
            <motion.div
              initial={{ opacity: 0 }}
              whileHover={{ opacity: 1 }}
              className="p-1"
            >
              <Info className="w-3 h-3 text-accent" />
            </motion.div>
          </div>
        </div>
        <div className="w-full bg-secondary rounded-full h-2 group-hover:h-3 transition-all">
          <motion.div 
            className={`skill-bar h-full rounded-full transition-all duration-1000 ease-out ${color} relative overflow-hidden`}
            style={{ 
              width: isVisible ? `${percentage}%` : '0%'
            }}
            whileHover={{ 
              boxShadow: "0 0 10px rgba(139, 92, 246, 0.5)"
            }}
          >
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
              animate={{ x: ["-100%", "100%"] }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            />
          </motion.div>
        </div>
      </motion.div>

      <SkillModal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        skill={{
          name,
          percentage,
          color,
          ...currentSkill
        }}
      />
    </>
  );
}

export default function SkillsSection() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  const tools = [
    { icon: Github, name: "GitHub" },
    { icon: Database, name: "PyCharm" },
    { icon: FileCode, name: "VSCode" },
    { icon: Cloud, name: "AWS" },
    { icon: BarChart3, name: "Jupyter" },
    { icon: MapPin, name: "Maps API" },
  ];

  return (
    <section id="skills" className="py-20" data-testid="skills-section">
      <div className="max-w-6xl mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
        >
          <motion.h2 
            className="text-3xl md:text-4xl font-bold mb-4"
            variants={itemVariants}
            data-testid="skills-title"
          >
            Skill Tree
          </motion.h2>
          <motion.p 
            className="text-muted-foreground text-lg"
            variants={itemVariants}
            data-testid="skills-subtitle"
          >
            Abilities unlocked through countless hours of grinding
          </motion.p>
        </motion.div>

        <motion.div 
          className="grid lg:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
        >
          {/* Programming Skills */}
          <motion.div variants={itemVariants}>
            <Card className="border border-border shadow-sm hover:shadow-md transition-shadow h-full">
              <CardContent className="p-6">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mr-4">
                    <Code className="text-accent text-xl" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold" data-testid="programming-skills-title">Programming</h3>
                    <p className="text-sm text-muted-foreground">Core Development</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <SkillBar name="Java" percentage={90} color="bg-accent" delay={200} />
                  <SkillBar name="Python" percentage={85} color="bg-chart-2" delay={400} />
                  <SkillBar name="TypeScript" percentage={80} color="bg-chart-4" delay={600} />
                  <SkillBar name="SQL" percentage={75} color="bg-chart-1" delay={800} />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Web Technologies */}
          <motion.div variants={itemVariants}>
            <Card className="border border-border shadow-sm hover:shadow-md transition-shadow h-full">
              <CardContent className="p-6">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 bg-chart-2/10 rounded-lg flex items-center justify-center mr-4">
                    <Globe className="text-chart-2 text-xl" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold" data-testid="web-development-title">Web Development</h3>
                    <p className="text-sm text-muted-foreground">Frontend & Backend</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <SkillBar name="React" percentage={88} color="bg-chart-2" delay={300} />
                  <SkillBar name="HTML/CSS" percentage={92} color="bg-accent" delay={500} />
                  <SkillBar name="AWS" percentage={70} color="bg-chart-4" delay={700} />
                  <SkillBar name="APIs" percentage={78} color="bg-chart-1" delay={900} />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Data Science */}
          <motion.div variants={itemVariants}>
            <Card className="border border-border shadow-sm hover:shadow-md transition-shadow h-full">
              <CardContent className="p-6">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 bg-chart-4/10 rounded-lg flex items-center justify-center mr-4">
                    <TrendingUp className="text-chart-4 text-xl" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold" data-testid="data-science-title">Data Science</h3>
                    <p className="text-sm text-muted-foreground">Analytics & ML</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <SkillBar name="Data Analysis" percentage={82} color="bg-chart-4" delay={400} />
                  <SkillBar name="Statistics" percentage={78} color="bg-accent" delay={600} />
                  <SkillBar name="Jupyter" percentage={85} color="bg-chart-2" delay={800} />
                  <SkillBar name="Business Analytics" percentage={75} color="bg-chart-1" delay={1000} />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>

        {/* Tools & Technologies */}
        <motion.div 
          className="mt-12"
          variants={itemVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
        >
          <Card className="border border-border shadow-sm">
            <CardContent className="p-8">
              <h3 className="text-xl font-semibold mb-6 text-center flex items-center justify-center" data-testid="toolkit-title">
                <Code className="text-accent mr-2" />
                Toolkit & Arsenal
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                {tools.map((tool, index) => (
                  <motion.div
                    key={tool.name}
                    className="flex flex-col items-center p-4 bg-secondary rounded-lg hover:bg-accent/10 transition-colors cursor-pointer"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    viewport={{ once: true }}
                    data-testid={`tool-${tool.name.toLowerCase()}`}
                  >
                    <tool.icon className="text-2xl mb-2" />
                    <span className="text-sm">{tool.name}</span>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}
