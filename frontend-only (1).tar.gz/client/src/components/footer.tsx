import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Mail, Linkedin, Github } from "lucide-react";
export default function Footer() {

  const socialLinks = [
    {
      href: "mailto:aditirad@berkeley.edu",
      icon: Mail,
      label: "Email",
    },
    {
      href: "https://www.linkedin.com/in/aditirad/",
      icon: Linkedin,
      label: "LinkedIn",
    },
    {
      href: "https://github.com",
      icon: Github,
      label: "GitHub",
    },
  ];

  return (
    <footer className="bg-primary text-primary-foreground py-12" data-testid="footer">
      <div className="max-w-6xl mx-auto px-4">
        <motion.div 
          className="text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div className="text-2xl font-bold mb-4" data-testid="footer-title">
            Aditi Radhakrishnan
          </div>
          <p className="text-primary-foreground/80 mb-6" data-testid="footer-subtitle">
            Data Science Student • Software Developer • Community Impact Maker
          </p>
          
          <div className="flex justify-center space-x-6 mb-8" data-testid="footer-social-links">
            {socialLinks.map((link) => (
              <motion.div
                key={link.label}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <Button
                  variant="ghost"
                  size="sm"
                  asChild
                  className="text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/10"
                  data-testid={`footer-link-${link.label.toLowerCase()}`}
                >
                  <a 
                    href={link.href}
                    target={link.href.startsWith('mailto:') ? '_self' : '_blank'}
                    rel={link.href.startsWith('mailto:') ? undefined : 'noopener noreferrer'}
                    aria-label={link.label}
                  >
                    <link.icon className="h-5 w-5" />
                  </a>
                </Button>
              </motion.div>
            ))}
          </div>
          
          <div className="border-t border-primary-foreground/20 pt-6">
            <p className="text-sm text-primary-foreground/60" data-testid="footer-copyright">
              © 2025 Aditi Radhakrishnan. Crafted with ❤️ and lots of ☕
            </p>
          </div>
        </motion.div>
      </div>
    </footer>
  );
}
