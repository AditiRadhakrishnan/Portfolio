import { useState, useEffect } from "react";
import { motion } from "framer-motion";

export default function CustomCursor() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isHovering, setIsHovering] = useState(false);
  const [isClicking, setIsClicking] = useState(false);
  const [isMoving, setIsMoving] = useState(false);
  const [velocity, setVelocity] = useState({ x: 0, y: 0 });
  const [lastPosition, setLastPosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    let movingTimer: NodeJS.Timeout;
    
    const updateMousePosition = (e: MouseEvent) => {
      const newX = e.clientX;
      const newY = e.clientY;
      
      // Calculate velocity for motion effects
      const vx = newX - lastPosition.x;
      const vy = newY - lastPosition.y;
      setVelocity({ x: vx, y: vy });
      
      setMousePosition({ x: newX, y: newY });
      setLastPosition({ x: newX, y: newY });
      
      // Detect movement
      setIsMoving(true);
      clearTimeout(movingTimer);
      movingTimer = setTimeout(() => setIsMoving(false), 150);
    };

    const handleMouseDown = () => setIsClicking(true);
    const handleMouseUp = () => setIsClicking(false);

    const handleMouseEnter = (e: Event) => {
      const target = e.target as HTMLElement;
      if (
        target.tagName === "BUTTON" ||
        target.tagName === "A" ||
        target.classList.contains("cursor-pointer") ||
        target.closest("button") ||
        target.closest("a")
      ) {
        setIsHovering(true);
      }
    };

    const handleMouseLeave = (e: Event) => {
      const target = e.target as HTMLElement;
      if (
        target.tagName === "BUTTON" ||
        target.tagName === "A" ||
        target.classList.contains("cursor-pointer") ||
        target.closest("button") ||
        target.closest("a")
      ) {
        setIsHovering(false);
      }
    };

    // Add global event listeners
    document.addEventListener("mousemove", updateMousePosition);
    document.addEventListener("mousedown", handleMouseDown);
    document.addEventListener("mouseup", handleMouseUp);
    document.addEventListener("mouseover", handleMouseEnter);
    document.addEventListener("mouseout", handleMouseLeave);

    return () => {
      document.removeEventListener("mousemove", updateMousePosition);
      document.removeEventListener("mousedown", handleMouseDown);
      document.removeEventListener("mouseup", handleMouseUp);
      document.removeEventListener("mouseover", handleMouseEnter);
      document.removeEventListener("mouseout", handleMouseLeave);
      clearTimeout(movingTimer);
    };
  }, []);

  const speedMultiplier = Math.min(Math.sqrt(velocity.x ** 2 + velocity.y ** 2) / 10, 2);

  return (
    <>
      {/* Velocity-based glow effect */}
      <motion.div
        className="fixed top-0 left-0 w-12 h-12 bg-gradient-to-r from-accent/10 to-chart-2/10 rounded-full pointer-events-none z-10 blur-sm"
        style={{
          x: mousePosition.x - 24,
          y: mousePosition.y - 24,
        }}
        animate={{
          scale: isMoving ? 1.2 + speedMultiplier * 0.3 : 0.8,
          opacity: isMoving ? 0.6 : 0.2,
        }}
        transition={{
          type: "spring",
          stiffness: 200,
          damping: 20,
        }}
      />

      {/* Main cursor dot with pulse */}
      <motion.div
        className="fixed top-0 left-0 w-2 h-2 rounded-full pointer-events-none z-50"
        style={{
          x: mousePosition.x - 4,
          y: mousePosition.y - 4,
          background: isHovering 
            ? "linear-gradient(45deg, hsl(271.5, 81.3%, 55.9%), hsl(173, 58%, 39%))"
            : "hsl(271.5, 81.3%, 55.9%)",
        }}
        animate={{
          scale: isClicking ? 0.3 : isHovering ? 1.3 : 1,
          boxShadow: isMoving 
            ? `0 0 ${8 + speedMultiplier * 4}px rgba(139, 92, 246, 0.6)`
            : "0 0 4px rgba(139, 92, 246, 0.3)",
        }}
        transition={{
          type: "spring",
          stiffness: 500,
          damping: 30,
        }}
      />

      {/* Dynamic outer ring */}
      <motion.div
        className="fixed top-0 left-0 border-2 rounded-full pointer-events-none z-40"
        style={{
          x: mousePosition.x - (isHovering ? 20 : 16),
          y: mousePosition.y - (isHovering ? 20 : 16),
          width: isHovering ? 40 : 32,
          height: isHovering ? 40 : 32,
          borderColor: isHovering 
            ? "hsl(271.5, 81.3%, 55.9%)" 
            : "hsl(271.5, 81.3%, 55.9%)",
        }}
        animate={{
          scale: isClicking ? 0.8 : 1,
          opacity: isHovering ? 0.9 : 0.4,
          rotate: isMoving ? speedMultiplier * 45 : 0,
        }}
        transition={{
          type: "spring",
          stiffness: 300,
          damping: 25,
          rotate: { duration: 0.5 }
        }}
      />

      {/* Enhanced trailing particles with different colors */}
      <motion.div
        className="fixed top-0 left-0 w-1.5 h-1.5 bg-accent/40 rounded-full pointer-events-none z-30"
        style={{
          x: mousePosition.x - 3,
          y: mousePosition.y - 3,
        }}
        transition={{
          type: "spring",
          stiffness: 200,
          damping: 20,
          delay: 0.05,
        }}
      />
      <motion.div
        className="fixed top-0 left-0 w-1 h-1 bg-chart-2/30 rounded-full pointer-events-none z-25"
        style={{
          x: mousePosition.x - 2,
          y: mousePosition.y - 2,
        }}
        transition={{
          type: "spring",
          stiffness: 150,
          damping: 15,
          delay: 0.1,
        }}
      />
      <motion.div
        className="fixed top-0 left-0 w-0.5 h-0.5 bg-chart-4/20 rounded-full pointer-events-none z-20"
        style={{
          x: mousePosition.x - 1,
          y: mousePosition.y - 1,
        }}
        transition={{
          type: "spring",
          stiffness: 100,
          damping: 10,
          delay: 0.15,
        }}
      />

      {/* Sparkle effect on click */}
      {isClicking && (
        <motion.div
          className="fixed top-0 left-0 pointer-events-none z-45"
          style={{
            x: mousePosition.x - 12,
            y: mousePosition.y - 12,
          }}
          initial={{ scale: 0, rotate: 0 }}
          animate={{ scale: [0, 1, 0], rotate: 360 }}
          exit={{ scale: 0 }}
          transition={{ duration: 0.4 }}
        >
          {[...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-accent rounded-full"
              style={{
                x: Math.cos((i * Math.PI * 2) / 6) * 12,
                y: Math.sin((i * Math.PI * 2) / 6) * 12,
              }}
              animate={{
                scale: [0, 1, 0],
                x: Math.cos((i * Math.PI * 2) / 6) * 20,
                y: Math.sin((i * Math.PI * 2) / 6) * 20,
              }}
              transition={{
                duration: 0.4,
                delay: i * 0.05,
              }}
            />
          ))}
        </motion.div>
      )}
    </>
  );
}