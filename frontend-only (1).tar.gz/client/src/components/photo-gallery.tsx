import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import cert1 from "@assets/award1_1756924787539.jpeg";
import cert2 from "@assets/award2_1756924787539.jpeg";

const photos = [
  {
    src: cert1,
    alt: "San Joaquin County Board of Supervisors Certificate of Recognition",
    caption: "County Recognition for Animal Rescue Dedication"
  },
  {
    src: cert2,
    alt: "Certificate of Achievement from Animal Rescue of Tracy",
    caption: "Compassion to Action Internship Program Completion"
  }
];

const photoVariants = {
  enter: (direction: number) => ({
    x: direction > 0 ? 1000 : -1000,
    opacity: 0,
    scale: 0.8,
    rotateY: direction > 0 ? 45 : -45,
  }),
  center: {
    zIndex: 1,
    x: 0,
    opacity: 1,
    scale: 1,
    rotateY: 0,
  },
  exit: (direction: number) => ({
    zIndex: 0,
    x: direction < 0 ? 1000 : -1000,
    opacity: 0,
    scale: 0.8,
    rotateY: direction < 0 ? 45 : -45,
  }),
};

const swipeConfidenceThreshold = 10000;
const swipePower = (offset: number, velocity: number) => {
  return Math.abs(offset) * velocity;
};

export default function PhotoGallery() {
  const [[page, direction], setPage] = useState([0, 0]);
  
  const imageIndex = ((page % photos.length) + photos.length) % photos.length;

  const paginate = (newDirection: number) => {
    setPage([page + newDirection, newDirection]);
  };

  return (
    <section className="py-20 px-4" data-testid="photo-gallery-section">
      <div className="container mx-auto max-w-4xl">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl font-bold mb-4" data-testid="gallery-title">
            Recognition Gallery
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto" data-testid="gallery-subtitle">
            Official certificates and awards recognizing dedication to animal welfare and community service
          </p>
        </motion.div>

        <div className="relative">
          {/* Main Photo Display */}
          <div className="relative h-[500px] md:h-[600px] rounded-2xl overflow-hidden bg-gradient-to-br from-accent/10 to-chart-2/10 shadow-2xl">
            <AnimatePresence initial={false} custom={direction}>
              <motion.div
                key={page}
                custom={direction}
                variants={photoVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{
                  x: { type: "spring", stiffness: 300, damping: 30 },
                  opacity: { duration: 0.2 },
                  scale: { duration: 0.4 },
                  rotateY: { duration: 0.4 }
                }}
                drag="x"
                dragConstraints={{ left: 0, right: 0 }}
                dragElastic={1}
                onDragEnd={(e, { offset, velocity }) => {
                  const swipe = swipePower(offset.x, velocity.x);

                  if (swipe < -swipeConfidenceThreshold) {
                    paginate(1);
                  } else if (swipe > swipeConfidenceThreshold) {
                    paginate(-1);
                  }
                }}
                className="absolute inset-0 cursor-pointer"
                data-testid={`photo-${imageIndex}`}
                onClick={() => paginate(1)}
              >
                <div className="relative h-full w-full group">
                  <img
                    src={photos[imageIndex].src}
                    alt={photos[imageIndex].alt}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  
                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                  
                  {/* Photo Caption */}
                  <motion.div
                    className="absolute bottom-0 left-0 right-0 p-6 text-white"
                    initial={{ y: 50, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.3, duration: 0.5 }}
                  >
                    <div className="bg-black/30 backdrop-blur-sm rounded-lg p-4">
                      <p className="text-lg font-medium" data-testid={`caption-${imageIndex}`}>
                        {photos[imageIndex].caption}
                      </p>
                    </div>
                  </motion.div>

                  {/* Click to continue hint */}
                  <motion.div
                    className="absolute top-4 right-4 bg-white/20 backdrop-blur-sm rounded-full p-2 opacity-0 group-hover:opacity-100"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.5 }}
                  >
                    <span className="text-white text-sm font-medium px-2">Click to continue →</span>
                  </motion.div>
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Navigation Arrows */}
            <button
              className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/20 backdrop-blur-sm hover:bg-white/30 rounded-full p-3 transition-all duration-300 opacity-0 hover:opacity-100 group-hover:opacity-100"
              onClick={(e) => {
                e.stopPropagation();
                paginate(-1);
              }}
              data-testid="gallery-prev-button"
            >
              <ChevronLeft className="w-6 h-6 text-white" />
            </button>
            
            <button
              className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/20 backdrop-blur-sm hover:bg-white/30 rounded-full p-3 transition-all duration-300 opacity-0 hover:opacity-100 group-hover:opacity-100"
              onClick={(e) => {
                e.stopPropagation();
                paginate(1);
              }}
              data-testid="gallery-next-button"
            >
              <ChevronRight className="w-6 h-6 text-white" />
            </button>
          </div>

          {/* Photo Indicators */}
          <div className="flex justify-center mt-8 space-x-3">
            {photos.map((_, index) => (
              <motion.button
                key={index}
                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                  index === imageIndex
                    ? "bg-accent scale-125 shadow-lg"
                    : "bg-muted-foreground/30 hover:bg-muted-foreground/50"
                }`}
                onClick={() => {
                  const newDirection = index > imageIndex ? 1 : -1;
                  setPage([index, newDirection]);
                }}
                whileHover={{ scale: 1.2 }}
                whileTap={{ scale: 0.9 }}
                data-testid={`indicator-${index}`}
              />
            ))}
          </div>

          {/* Photo Counter */}
          <motion.div
            className="text-center mt-4 text-muted-foreground"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <span className="text-sm" data-testid="photo-counter">
              {imageIndex + 1} of {photos.length}
            </span>
          </motion.div>
        </div>
      </div>
    </section>
  );
}