import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, User, MapPin, Calendar, Camera } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import photo1 from "@assets/IMG_4587_1756927842582.jpg";
import photo2 from "@assets/IMG_4590_1756928494729.jpg";
import photo3 from "@assets/pic1_1756930394042.jpg";
import photo4 from "@assets/IMG_5847_1756930540128.jpeg";

const profiles = [
  {
    id: 1,
    image: photo1,
    title: "The Explorer",
    location: "UC Berkeley Campus", 
    date: "2024",
    description: "Discovering new perspectives and embracing the journey of learning at one of the world's top universities.",
    mood: "Adventurous & Curious",
    color: "from-blue-500 to-purple-600",
    position: "60% center"
  },
  {
    id: 2,
    image: photo2,
    title: "The Achiever",
    location: "Graduation Setting",
    date: "2024", 
    description: "Celebrating milestones and achievements while looking forward to the exciting opportunities ahead.",
    mood: "Accomplished & Determined",
    color: "from-emerald-500 to-teal-600",
    position: "center center"
  },
  {
    id: 3,
    image: photo3,
    title: "The Graduate",
    location: "Graduation Garden",
    date: "2024",
    description: "Proudly celebrating academic achievements in beautiful graduation attire, surrounded by vibrant flowers marking this significant milestone.",
    mood: "Proud & Accomplished",
    color: "from-purple-500 to-indigo-600",
    position: "center center"
  },
  {
    id: 4,
    image: photo4,
    title: "The Adventurer",
    location: "Campus Life", 
    date: "2024",
    description: "Embracing the college experience with joy and enthusiasm, creating memories that will last a lifetime.",
    mood: "Joyful & Enthusiastic",
    color: "from-cyan-500 to-blue-600",
    position: "center 30%"
  }
];

const slideVariants = {
  enter: (direction: number) => ({
    x: direction > 0 ? 300 : -300,
    opacity: 0,
    scale: 0.8,
  }),
  center: {
    zIndex: 1,
    x: 0,
    opacity: 1,
    scale: 1,
  },
  exit: (direction: number) => ({
    zIndex: 0,
    x: direction < 0 ? 300 : -300,
    opacity: 0,
    scale: 0.8,
  })
};

export default function CharacterProfile() {
  const [[page, direction], setPage] = useState([0, 0]);
  const [autoSlide, setAutoSlide] = useState(true);

  const profileIndex = ((page % profiles.length) + profiles.length) % profiles.length;
  const currentProfile = profiles[profileIndex];

  const paginate = (newDirection: number) => {
    setPage([page + newDirection, newDirection]);
    setAutoSlide(false);
    
    // Resume auto-slide after 15 seconds
    setTimeout(() => setAutoSlide(true), 15000);
  };

  // Auto-slide functionality
  useEffect(() => {
    if (!autoSlide) return;
    
    const interval = setInterval(() => {
      setPage(([currentPage, _]) => [currentPage + 1, 1]);
    }, 6000);

    return () => clearInterval(interval);
  }, [autoSlide]);

  return (
    <section className="py-20 px-4 bg-gradient-to-br from-muted/30 to-secondary/30" data-testid="character-profile-section">
      <div className="container mx-auto max-w-4xl">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="profile-title">
            Character Profile
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto" data-testid="profile-subtitle">
            Different facets of my journey through data science and personal growth
          </p>
        </motion.div>

        <div className="relative">
          <Card className="overflow-hidden border-0 shadow-2xl bg-gradient-to-br from-background/95 to-muted/50 backdrop-blur-sm">
            <CardContent className="p-0">
              <div className="relative h-[500px] md:h-[600px]">
                <AnimatePresence initial={false} custom={direction}>
                  <motion.div
                    key={page}
                    custom={direction}
                    variants={slideVariants}
                    initial="enter"
                    animate="center"
                    exit="exit"
                    transition={{
                      x: { type: "spring", stiffness: 300, damping: 30 },
                      opacity: { duration: 0.2 },
                      scale: { duration: 0.4 }
                    }}
                    className="absolute inset-0"
                    data-testid={`profile-slide-${profileIndex}`}
                  >
                    <div className="flex flex-col md:flex-row h-full">
                      {/* Image Section */}
                      <div className="relative md:w-1/2 h-full">
                        <motion.img
                          src={currentProfile.image}
                          alt={currentProfile.title}
                          className="w-full h-full object-cover"
                          style={{ 
                            objectPosition: currentProfile.position
                          }}
                          initial={{ scale: 1.1 }}
                          animate={{ scale: 1 }}
                          transition={{ duration: 0.8 }}
                        />
                        
                        {/* Image Overlay */}
                        <div className={`absolute inset-0 bg-gradient-to-r ${currentProfile.color} opacity-20`} />
                        
                        {/* Camera Badge */}
                        <motion.div
                          className="absolute top-4 right-4 bg-white/20 backdrop-blur-sm rounded-full p-2"
                          initial={{ scale: 0, rotate: -180 }}
                          animate={{ scale: 1, rotate: 0 }}
                          transition={{ delay: 0.5, duration: 0.5 }}
                        >
                          <Camera className="w-4 h-4 text-white" />
                        </motion.div>
                      </div>

                      {/* Content Section */}
                      <div className="md:w-1/2 p-8 flex flex-col justify-center relative">
                        <motion.div
                          initial={{ y: 30, opacity: 0 }}
                          animate={{ y: 0, opacity: 1 }}
                          transition={{ delay: 0.3, duration: 0.6 }}
                        >
                          {/* Profile Header */}
                          <div className="flex items-center gap-3 mb-6">
                            <motion.div 
                              className={`w-12 h-12 rounded-full bg-gradient-to-r ${currentProfile.color} flex items-center justify-center`}
                              whileHover={{ scale: 1.1, rotate: 180 }}
                              transition={{ duration: 0.3 }}
                            >
                              <User className="w-6 h-6 text-white" />
                            </motion.div>
                            <div>
                              <h3 className="text-2xl font-bold text-foreground" data-testid={`profile-name-${profileIndex}`}>
                                {currentProfile.title}
                              </h3>
                              <p className="text-sm text-muted-foreground" data-testid={`profile-mood-${profileIndex}`}>
                                {currentProfile.mood}
                              </p>
                            </div>
                          </div>

                          {/* Location and Date */}
                          <div className="flex flex-wrap gap-4 mb-6 text-sm">
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <MapPin className="w-4 h-4" />
                              <span data-testid={`profile-location-${profileIndex}`}>{currentProfile.location}</span>
                            </div>
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <Calendar className="w-4 h-4" />
                              <span data-testid={`profile-date-${profileIndex}`}>{currentProfile.date}</span>
                            </div>
                          </div>

                          {/* Description */}
                          <p className="text-foreground leading-relaxed mb-6" data-testid={`profile-description-${profileIndex}`}>
                            {currentProfile.description}
                          </p>

                          {/* Progress Indicator */}
                          <div className="flex gap-2">
                            {profiles.map((_, index) => (
                              <motion.div
                                key={index}
                                className={`h-1 rounded-full transition-all duration-300 ${
                                  index === profileIndex
                                    ? `bg-gradient-to-r ${currentProfile.color} w-8`
                                    : "bg-muted w-2"
                                }`}
                                whileHover={{ scale: 1.2 }}
                              />
                            ))}
                          </div>
                        </motion.div>
                      </div>
                    </div>
                  </motion.div>
                </AnimatePresence>

                {/* Navigation Arrows */}
                <button
                  className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-background/80 hover:bg-background rounded-full p-3 transition-all duration-300 z-10 shadow-lg"
                  onClick={() => paginate(-1)}
                  data-testid="profile-prev-button"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                
                <button
                  className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-background/80 hover:bg-background rounded-full p-3 transition-all duration-300 z-10 shadow-lg"
                  onClick={() => paginate(1)}
                  data-testid="profile-next-button"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </CardContent>
          </Card>

          {/* Auto-slide indicator */}
          {autoSlide && (
            <motion.div
              className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-muted/80 text-muted-foreground text-xs px-3 py-1 rounded-full"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
            >
              Auto-sliding • Click to control
            </motion.div>
          )}
        </div>
      </div>
    </section>
  );
}