import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Award, Trophy, Medal, Star } from "lucide-react";
import award1 from "@assets/try1_1756934006586.jpeg";
import award2 from "@assets/try2_1756934006586.jpeg";
import award3 from "@assets/award3_1756924787539.jpeg";
import award4 from "@assets/award4_1756924787540.jpeg";

interface AwardData {
  id: string;
  title: string;
  organization: string;
  year: string;
  description: string;
  image: string;
  category: string;
  icon: React.ReactNode;
}

const awards: AwardData[] = [
  {
    id: "congressional-recognition",
    title: "Certificate of Congressional Recognition",
    organization: "Josh Harder - U.S. Congressman, United States House of Representatives",
    year: "2023",
    description: "Congressional recognition for developing FindMyPaw to help reunite lost pets with their families.",
    image: award4,
    category: "Government Recognition",
    icon: <Award className="w-6 h-6" />
  },
  {
    id: "internship-completion", 
    title: "Certificate of Achievement",
    organization: "Julie Selner - Animal Rescue of Tracy President",
    year: "2023",
    description: "Achievement recognition for building FindMyPaw, a platform supporting animal welfare through technology.",
    image: award2,
    category: "Professional Development",
    icon: <Trophy className="w-6 h-6" />
  },
  {
    id: "city-recognition",
    title: "Certificate of Recognition from the City of Tracy",
    organization: "Nancy D. Young - Mayor of the City of Tracy",
    year: "2023", 
    description: "Municipal recognition for creating a technology solution to help lost pets find their way home.",
    image: award3,
    category: "Municipal Recognition",
    icon: <Medal className="w-6 h-6" />
  },
  {
    id: "county-recognition",
    title: "Board of Supervisors Certificate of Recognition",
    organization: "Robert Rickman - Chair of the Board of Supervisors, San Joaquin County, California",
    year: "2023",
    description: "Recognition for creating FindMyPaw, a technology platform helping reunite lost pets with their families.",
    image: award1,
    category: "County Recognition",
    icon: <Star className="w-6 h-6" />
  }
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { duration: 0.6, ease: "easeOut" }
  }
};

function AwardCard({ award }: { award: AwardData }) {
  const getCategoryColor = (category: string) => {
    const colorMap: Record<string, string> = {
      "Government Recognition": "bg-chart-1/10 text-chart-1",
      "Professional Development": "bg-chart-2/10 text-chart-2", 
      "Municipal Recognition": "bg-chart-3/10 text-chart-3",
      "County Recognition": "bg-chart-4/10 text-chart-4"
    };
    return colorMap[category] || "bg-accent/10 text-accent";
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <motion.div
          variants={itemVariants}
          className="cursor-pointer"
          data-testid={`award-card-${award.id}`}
        >
          <Card className="group border border-border/50 shadow-sm hover:shadow-lg transition-all duration-300 overflow-hidden">
            <CardContent className="p-0">
              {/* Award Image */}
              <div className="relative overflow-hidden bg-muted/20">
                <motion.img
                  src={award.image}
                  alt={award.title}
                  className="w-full h-48 object-cover transition-transform duration-500 group-hover:scale-105"
                  whileHover={{ scale: 1.02 }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
                
                {/* Category Badge */}
                <div className="absolute top-3 left-3">
                  <Badge className={`${getCategoryColor(award.category)} border-0`}>
                    {award.icon}
                    <span className="ml-1">{award.category}</span>
                  </Badge>
                </div>

                {/* Year Badge */}
                <div className="absolute top-3 right-3">
                  <Badge variant="secondary" className="bg-background/80 backdrop-blur-sm">
                    {award.year}
                  </Badge>
                </div>
              </div>

              {/* Award Content */}
              <div className="p-6">
                <h3 className="font-bold text-lg mb-2 group-hover:text-accent transition-colors" data-testid={`award-title-${award.id}`}>
                  {award.title}
                </h3>
                <p className="text-muted-foreground text-sm mb-3" data-testid={`award-org-${award.id}`}>
                  {award.organization}
                </p>
                <p className="text-sm line-clamp-3" data-testid={`award-description-${award.id}`}>
                  {award.description}
                </p>

                {/* Hover Effect */}
                <motion.div
                  className="mt-4 flex items-center text-accent text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity"
                  initial={{ x: -10 }}
                  whileHover={{ x: 0 }}
                >
                  Click to view details →
                </motion.div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </DialogTrigger>

      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            {award.icon}
            {award.title}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Full Certificate Image */}
          <div className="relative group">
            <motion.img
              src={award.image}
              alt={award.title}
              className="w-full h-auto object-contain rounded-lg border border-border/20 shadow-lg cursor-zoom-in transition-transform duration-300"
              whileHover={{ scale: 1.02 }}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
            />
            
            {/* Overlay hint on hover */}
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors duration-300 rounded-lg flex items-center justify-center opacity-0 group-hover:opacity-100">
              <div className="bg-background/90 backdrop-blur-sm px-3 py-2 rounded-md text-sm font-medium">
                Hover to enlarge
              </div>
            </div>
          </div>
          
          {/* Certificate Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Issued By</p>
                <p className="font-medium text-base">{award.organization}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Year</p>
                <p className="font-medium text-base">{award.year}</p>
              </div>
              <div>
                <Badge className={`${getCategoryColor(award.category)} border-0 w-fit text-sm px-3 py-2`}>
                  {award.icon}
                  <span className="ml-2">{award.category}</span>
                </Badge>
              </div>
            </div>
            
            <div>
              <p className="text-sm text-muted-foreground mb-2">Recognition Details</p>
              <p className="text-sm leading-relaxed bg-muted/30 p-4 rounded-lg">{award.description}</p>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function AwardsGallery() {
  return (
    <section id="awards" className="py-20 px-4 bg-muted/30" data-testid="awards-section">
      <div className="container mx-auto max-w-6xl">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl font-bold mb-4" data-testid="awards-title">
            Awards & Recognition
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto" data-testid="awards-subtitle">
            Official recognition from government and community organizations for dedication to animal welfare and community service.
          </p>
        </motion.div>

        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {awards.map((award) => (
            <AwardCard key={award.id} award={award} />
          ))}
        </motion.div>
      </div>
    </section>
  );
}