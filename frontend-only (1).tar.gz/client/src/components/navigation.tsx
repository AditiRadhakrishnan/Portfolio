import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu, Download } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { ThemeToggle } from "@/components/theme-toggle";

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleDownloadResume = async () => {
    try {
      await apiRequest("GET", "/api/resume/download");
      // In a real implementation, this would trigger the actual download
      window.open("/resume_aditi_radhakrishnan.pdf", "_blank");
    } catch (error) {
      console.error("Failed to track resume download:", error);
    }
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const navLinks = [
    { href: "hero", label: "Home" },
    { href: "about", label: "About" },
    { href: "skills", label: "Skills" },
    { href: "projects", label: "Projects" },
    { href: "achievements", label: "Achievements" },
    { href: "awards", label: "Awards" },
    { href: "contact", label: "Contact" },
  ];

  return (
    <nav 
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? "glass-effect shadow-lg" : "bg-transparent"
      }`}
      data-testid="navigation"
    >
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-3 sm:py-4">
          <div className="text-lg sm:text-xl font-bold text-accent" data-testid="logo">
            AR <span className="text-xs sm:text-sm text-muted-foreground">Level 19</span>
          </div>
          
          <div className="hidden md:flex space-x-8">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => scrollToSection(link.href)}
                className="hover:text-accent transition-colors text-sm font-medium"
                data-testid={`nav-link-${link.href}`}
              >
                {link.label}
              </button>
            ))}
          </div>
          
          <div className="flex items-center space-x-2 sm:space-x-4">
            <ThemeToggle />
            <Button
              variant="outline"
              size="sm"
              onClick={handleDownloadResume}
              className="hidden md:flex"
              data-testid="button-download-resume"
            >
              <Download className="w-4 h-4 mr-2" />
              Resume
            </Button>
            
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" className="md:hidden" data-testid="button-mobile-menu">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent>
                <div className="flex flex-col space-y-6 mt-8">
                  {navLinks.map((link) => (
                    <button
                      key={link.href}
                      onClick={() => scrollToSection(link.href)}
                      className="text-left hover:text-accent transition-colors py-3 text-lg font-medium border-b border-border/20 last:border-b-0"
                      data-testid={`mobile-nav-link-${link.href}`}
                    >
                      {link.label}
                    </button>
                  ))}
                  <Button
                    onClick={handleDownloadResume}
                    className="mt-6 w-full"
                    data-testid="mobile-button-download-resume"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download Resume
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
}