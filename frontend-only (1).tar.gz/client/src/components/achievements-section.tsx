import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Trophy, Award, GraduationCap, Star, Code, BarChart3, Users, HelpCircle, Sparkles, Zap } from "lucide-react";
import { useState } from "react";
import type { Achievement } from "@shared/schema";

function AchievementBadge({ achievement, onUnlock }: { achievement: Achievement; onUnlock?: (id: string) => void }) {
  const [isAnimating, setIsAnimating] = useState(false);

  const getIcon = (iconEmoji: string) => {
    const iconMap: Record<string, React.ReactNode> = {
      "🏛️": <Award className="text-2xl" />,
      "🏆": <Trophy className="text-2xl" />,
      "🎓": <GraduationCap className="text-2xl" />,
      "🌟": <Star className="text-2xl" />,
      "💻": <Code className="text-2xl" />,
      "📊": <BarChart3 className="text-2xl" />,
      "🧑‍🏫": <Users className="text-2xl" />,
      "❓": <HelpCircle className="text-2xl" />,
    };
    return iconMap[iconEmoji] || <span className="text-2xl">{iconEmoji}</span>;
  };

  const handleClick = () => {
    if (!achievement.unlocked && onUnlock) {
      setIsAnimating(true);
      onUnlock(achievement.id);
      setTimeout(() => setIsAnimating(false), 1000);
    }
  };

  const getCategoryColor = (category: string) => {
    const colorMap: Record<string, string> = {
      "Epic Achievement": "bg-chart-1/10 text-chart-1",
      "Regional Honor": "bg-chart-2/10 text-chart-2",
      "Perfect Score": "bg-accent/10 text-accent",
      "Social Hero": "bg-chart-4/10 text-chart-4",
      "Tech Master": "bg-primary/10 text-primary",
      "In Progress": "bg-destructive/10 text-destructive",
      "Mentor": "bg-chart-3/10 text-chart-3",
      "Hidden": "bg-muted/10 text-muted-foreground",
    };
    return colorMap[category] || "bg-muted/10 text-muted-foreground";
  };

  const getGradientColor = (category: string) => {
    const gradientMap: Record<string, string> = {
      "Epic Achievement": "from-chart-1 to-chart-1/50",
      "Regional Honor": "from-chart-2 to-chart-2/50",
      "Perfect Score": "from-accent to-accent/50",
      "Social Hero": "from-chart-4 to-chart-4/50",
      "Tech Master": "from-primary to-primary/50",
      "In Progress": "from-destructive to-destructive/50",
      "Mentor": "from-chart-3 to-chart-3/50",
      "Hidden": "from-muted to-muted/50",
    };
    return gradientMap[category] || "from-muted to-muted/50";
  };

  return (
    <motion.div
      className={`achievement-badge bg-card rounded-xl p-6 border border-border shadow-sm text-center cursor-pointer relative overflow-hidden ${
        !achievement.unlocked ? 'opacity-60 hover:opacity-80' : ''
      }`}
      whileHover={{ 
        scale: 1.05, 
        rotate: achievement.unlocked ? 2 : 0,
        boxShadow: achievement.unlocked 
          ? "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)"
          : "0 10px 15px -3px rgba(139, 92, 246, 0.1), 0 4px 6px -2px rgba(139, 92, 246, 0.05)"
      }}
      whileTap={{ scale: 0.95 }}
      onClick={handleClick}
      data-testid={`achievement-${achievement.id}`}
      animate={isAnimating ? {
        scale: [1, 1.2, 1],
        rotate: [0, 360, 0],
        transition: { duration: 0.8, ease: "easeInOut" }
      } : {}}
    >
      {/* Animated background for unlocked achievements */}
      {achievement.unlocked && (
        <motion.div
          className="absolute inset-0 bg-gradient-to-br from-accent/10 to-chart-2/10 rounded-xl"
          animate={{
            background: [
              "linear-gradient(45deg, rgba(139, 92, 246, 0.1), rgba(6, 182, 212, 0.1))",
              "linear-gradient(135deg, rgba(6, 182, 212, 0.1), rgba(139, 92, 246, 0.1))",
              "linear-gradient(45deg, rgba(139, 92, 246, 0.1), rgba(6, 182, 212, 0.1))"
            ]
          }}
          transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
        />
      )}

      {/* Sparkle effect for unlocked achievements */}
      {achievement.unlocked && (
        <motion.div
          className="absolute top-2 right-2"
          animate={{
            rotate: [0, 360],
            scale: [1, 1.2, 1]
          }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <Sparkles className="w-4 h-4 text-chart-4" />
        </motion.div>
      )}

      {/* Pulse effect for locked achievements */}
      {!achievement.unlocked && (
        <motion.div
          className="absolute inset-0 border-2 border-accent/30 rounded-xl"
          animate={{
            scale: [1, 1.05, 1],
            opacity: [0.5, 1, 0.5]
          }}
          transition={{ duration: 2, repeat: Infinity }}
        />
      )}
      <motion.div 
        className={`w-16 h-16 bg-gradient-to-br ${getGradientColor(achievement.category)} rounded-full flex items-center justify-center mx-auto mb-4 relative z-10`}
        animate={achievement.unlocked ? {
          boxShadow: [
            "0 0 20px rgba(139, 92, 246, 0.5)",
            "0 0 30px rgba(6, 182, 212, 0.5)",
            "0 0 20px rgba(139, 92, 246, 0.5)"
          ]
        } : {}}
        transition={{ duration: 3, repeat: Infinity }}
      >
        {getIcon(achievement.icon)}
        
      </motion.div>
      <h3 className="font-semibold mb-2" data-testid={`achievement-title-${achievement.id}`}>
        {achievement.title}
      </h3>
      <p className="text-sm text-muted-foreground mb-3" data-testid={`achievement-description-${achievement.id}`}>
        {achievement.description}
      </p>
      <Badge className={`text-xs ${getCategoryColor(achievement.category)}`} data-testid={`achievement-category-${achievement.id}`}>
        {achievement.category}
      </Badge>
    </motion.div>
  );
}

export default function AchievementsSection() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: achievements = [], isLoading } = useQuery({
    queryKey: ["/api/achievements"],
  });

  const unlockMutation = useMutation({
    mutationFn: (achievementId: string) => 
      apiRequest("POST", `/api/achievements/${achievementId}/unlock`),
    onSuccess: (data, achievementId) => {
      queryClient.invalidateQueries({ queryKey: ["/api/achievements"] });
      
      // Create celebration effect
      createCelebrationEffect();
      
      toast({
        title: "Achievement Unlocked! 🎉",
        description: `You discovered the ${data.achievement?.title || 'secret achievement'}!`,
      });
    },
    onError: () => {
      toast({
        title: "Already unlocked!",
        description: "This achievement has already been discovered.",
        variant: "destructive",
      });
    },
  });

  const createCelebrationEffect = () => {
    const emojis = ['🎉', '🎊', '⭐', '🌟'];
    
    for (let i = 0; i < 20; i++) {
      setTimeout(() => {
        const confetti = document.createElement('div');
        confetti.innerHTML = emojis[Math.floor(Math.random() * emojis.length)];
        confetti.style.position = 'fixed';
        confetti.style.left = Math.random() * window.innerWidth + 'px';
        confetti.style.top = '-50px';
        confetti.style.fontSize = '24px';
        confetti.style.zIndex = '9999';
        confetti.style.pointerEvents = 'none';
        confetti.className = 'animate-fall';
        document.body.appendChild(confetti);
        
        setTimeout(() => {
          confetti.remove();
        }, 3000);
      }, i * 100);
    }
  };

  const handleUnlockAchievement = (achievementId: string) => {
    unlockMutation.mutate(achievementId);
  };

  const stats = [
    { value: "8+", label: "Projects Completed", color: "text-accent" },
    { value: "3+", label: "Years Experience", color: "text-chart-2" },
    { value: "500+", label: "Lives Impacted", color: "text-chart-4" },
    { value: "100%", label: "Dedication Level", color: "text-chart-1" },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  if (isLoading) {
    return (
      <section className="py-20 bg-secondary/30">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading achievements...</p>
        </div>
      </section>
    );
  }

  return (
    <section id="achievements" className="py-12 sm:py-20 bg-secondary/30" data-testid="achievements-section">
      <div className="max-w-6xl mx-auto px-3 sm:px-4">
        <motion.div 
          className="text-center mb-8 sm:mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-3 sm:mb-4" data-testid="achievements-title">
            Achievement Gallery
          </h2>
          <p className="text-muted-foreground text-lg" data-testid="achievements-subtitle">
            Badges earned through dedication and impact
          </p>
        </motion.div>

        <motion.div 
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-8 sm:mb-12"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
        >
          {achievements.map((achievement: Achievement) => (
            <motion.div key={achievement.id} variants={itemVariants}>
              <AchievementBadge 
                achievement={achievement} 
                onUnlock={handleUnlockAchievement}
              />
            </motion.div>
          ))}
        </motion.div>

        {/* Stats Dashboard */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6 }}
        >
          <Card className="border border-border shadow-sm">
            <CardContent className="p-8">
              <h3 className="text-xl font-semibold mb-6 text-center" data-testid="player-stats-title">
                Player Statistics
              </h3>
              <div className="grid md:grid-cols-4 gap-6" data-testid="player-stats-grid">
                {stats.map((stat, index) => (
                  <motion.div 
                    key={stat.label}
                    className="text-center"
                    initial={{ opacity: 0, scale: 0.5 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1, duration: 0.5 }}
                    data-testid={`stat-${stat.label.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    <div className={`text-3xl font-bold ${stat.color} mb-2`}>
                      {stat.value}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {stat.label}
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}
