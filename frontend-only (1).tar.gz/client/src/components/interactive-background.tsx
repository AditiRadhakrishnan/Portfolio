import { motion } from "framer-motion";
import { useEffect, useState } from "react";

export function InteractiveBackground() {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isMoving, setIsMoving] = useState(false);

  useEffect(() => {
    let timeout: NodeJS.Timeout;
    
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
      setIsMoving(true);
      
      clearTimeout(timeout);
      timeout = setTimeout(() => setIsMoving(false), 100);
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      clearTimeout(timeout);
    };
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-0">
      {/* Dynamic gradient that follows mouse */}
      <motion.div
        className="absolute w-96 h-96 rounded-full opacity-10"
        style={{
          background: 'radial-gradient(circle, rgba(139, 92, 246, 0.3) 0%, transparent 70%)',
          left: mousePos.x - 192,
          top: mousePos.y - 192,
        }}
        animate={{
          scale: isMoving ? 1.2 : 1,
          opacity: isMoving ? 0.2 : 0.1,
        }}
        transition={{ duration: 0.3 }}
      />
      
      {/* Geometric shapes that respond to mouse */}
      <motion.div
        className="absolute w-32 h-32 border border-accent/20 rounded-lg"
        style={{
          left: '10%',
          top: '20%',
        }}
        animate={{
          rotate: mousePos.x * 0.01,
          x: mousePos.x * 0.02,
          y: mousePos.y * 0.02,
        }}
        transition={{ type: "spring", damping: 50 }}
      />
      
      <motion.div
        className="absolute w-24 h-24 border border-chart-2/20 rounded-full"
        style={{
          right: '15%',
          top: '30%',
        }}
        animate={{
          rotate: -mousePos.x * 0.01,
          x: -mousePos.x * 0.015,
          y: mousePos.y * 0.015,
        }}
        transition={{ type: "spring", damping: 40 }}
      />
      
      <motion.div
        className="absolute w-40 h-40 border border-chart-4/20"
        style={{
          left: '80%',
          bottom: '20%',
          clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)',
        }}
        animate={{
          rotate: mousePos.y * 0.01,
          x: -mousePos.x * 0.01,
          y: -mousePos.y * 0.01,
        }}
        transition={{ type: "spring", damping: 45 }}
      />
    </div>
  );
}

export function ClickRipple() {
  const [ripples, setRipples] = useState<Array<{ x: number; y: number; id: number }>>([]);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      const newRipple = {
        x: e.clientX,
        y: e.clientY,
        id: Date.now(),
      };
      
      setRipples(prev => [...prev, newRipple]);
      
      // Remove ripple after animation
      setTimeout(() => {
        setRipples(prev => prev.filter(ripple => ripple.id !== newRipple.id));
      }, 1000);
    };

    document.addEventListener('click', handleClick);
    return () => document.removeEventListener('click', handleClick);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-50">
      {ripples.map(ripple => (
        <motion.div
          key={ripple.id}
          className="absolute w-4 h-4 border border-accent rounded-full"
          style={{
            left: ripple.x - 8,
            top: ripple.y - 8,
          }}
          initial={{ scale: 0, opacity: 1 }}
          animate={{ scale: 10, opacity: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
        />
      ))}
    </div>
  );
}