import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Play, Download, Code, BarChart3, Sparkles, ArrowDown, ChevronDown } from "lucide-react";
import { useState, useEffect } from "react";
import { ParticleSystem, FloatingElements } from "@/components/particle-system";
import { apiRequest } from "@/lib/queryClient";

interface HeroSectionProps {
  onStartQuest?: () => void;
}

export default function HeroSection({ onStartQuest }: HeroSectionProps) {
  const [displayText, setDisplayText] = useState("");
  const [currentIndex, setCurrentIndex] = useState(0);
  const fullText = "Data Science Student @ The University of California, Berkeley";

  useEffect(() => {
    if (currentIndex < fullText.length) {
      const timeout = setTimeout(() => {
        setDisplayText(prev => prev + fullText[currentIndex]);
        setCurrentIndex(prev => prev + 1);
      }, 100);
      return () => clearTimeout(timeout);
    } else {
      // After typing is complete, wait 3 seconds then restart
      const restartTimeout = setTimeout(() => {
        setDisplayText("");
        setCurrentIndex(0);
      }, 3000);
      return () => clearTimeout(restartTimeout);
    }
  }, [currentIndex, fullText]);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const handleDownloadResume = async () => {
    try {
      // Track the download event
      await apiRequest('GET', '/api/resume/download');
      
      // Create a download link and trigger it
      const link = document.createElement('a');
      link.href = '/resume_aditi_radhakrishnan.pdf';
      link.download = 'Aditi_Radhakrishnan_Resume.pdf';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error('Failed to download resume:', error);
      // Fallback to opening in new tab if download fails
      window.open('/resume_aditi_radhakrishnan.pdf', '_blank');
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  const floatVariants = {
    float: {
      y: [-10, 10, -10],
      transition: {
        duration: 6,
        repeat: Infinity,
        ease: "easeInOut",
      },
    },
  };

  return (
    <section 
      id="hero" 
      className="min-h-screen flex items-center justify-center relative overflow-hidden px-4 sm:px-6"
      data-testid="hero-section"
    >
      
      {/* Background with parallax effect */}
      <div 
        className="absolute inset-0 parallax opacity-5"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')`
        }}
      />

      {/* Subtle gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-accent/5 via-transparent to-chart-2/5" />
      
      <motion.div 
        className="relative z-10 text-center max-w-4xl mx-auto px-2 sm:px-4"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={itemVariants}>
          <div className="w-24 h-24 sm:w-32 sm:h-32 mx-auto mb-6 sm:mb-8 relative" data-testid="profile-avatar">
            <motion.div 
              className="w-full h-full rounded-full bg-gradient-to-r from-accent to-chart-2 flex items-center justify-center text-2xl sm:text-4xl text-white font-bold relative overflow-hidden cursor-pointer"
              whileHover={{ 
                scale: 1.1, 
                rotateY: 15,
                boxShadow: "0 0 30px rgba(139, 92, 246, 0.6)"
              }}
              whileTap={{ scale: 0.95 }}
              animate={{
                boxShadow: [
                  "0 0 20px rgba(139, 92, 246, 0.5)",
                  "0 0 40px rgba(6, 182, 212, 0.5)",
                  "0 0 20px rgba(139, 92, 246, 0.5)"
                ]
              }}
              transition={{ 
                boxShadow: { duration: 3, repeat: Infinity },
                hover: { duration: 0.3 }
              }}
            >
              AR
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
                initial={{ x: "-100%" }}
                animate={{ x: "100%" }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              />
            </motion.div>
            <motion.div 
              className="absolute -top-2 -right-2 bg-chart-4 text-primary text-xs px-2 py-1 rounded-full flex items-center gap-1"
              variants={floatVariants}
              animate="float"
              data-testid="status-badge"
              whileHover={{ scale: 1.2, rotate: 5 }}
            >
              <Sparkles className="w-3 h-3" />
              🚀 Online
            </motion.div>
          </div>
        </motion.div>
        
        <motion.h1 
          className="text-3xl sm:text-4xl md:text-6xl font-bold mb-4 sm:mb-6 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent"
          variants={itemVariants}
          data-testid="hero-title"
        >
          Aditi Radhakrishnan
        </motion.h1>
        
        <motion.div 
          className="text-lg sm:text-xl md:text-2xl text-muted-foreground mb-6 sm:mb-8 h-12 sm:h-16 flex items-center justify-center"
          variants={itemVariants}
          data-testid="hero-subtitle"
        >
          <span className="font-mono whitespace-nowrap text-center px-2">
            {displayText}
            <motion.span
              className="text-accent"
              animate={{ opacity: [0, 1, 0] }}
              transition={{ duration: 1, repeat: Infinity }}
            >
              |
            </motion.span>
          </span>
        </motion.div>
        
        <motion.div 
          className="flex flex-wrap justify-center gap-2 sm:gap-4 mb-6 sm:mb-8"
          variants={itemVariants}
        >
          <Badge variant="secondary" className="px-2 py-1 sm:px-4 sm:py-2 text-xs sm:text-sm" data-testid="badge-university">
            <i className="fas fa-graduation-cap text-accent mr-2"></i>
            UC Berkeley
          </Badge>
          <Badge variant="secondary" className="px-2 py-1 sm:px-4 sm:py-2 text-xs sm:text-sm" data-testid="badge-location">
            <i className="fas fa-map-marker-alt text-chart-1 mr-2"></i>
            San Francisco Bay Area
          </Badge>
          <Badge variant="secondary" className="px-2 py-1 sm:px-4 sm:py-2 text-xs sm:text-sm" data-testid="badge-status">
            <i className="fas fa-briefcase text-chart-2 mr-2"></i>
            Open for Internships
          </Badge>
        </motion.div>
        
        {/* Prompt Message */}
        <motion.div 
          className="text-center mb-8"
          variants={itemVariants}
          animate={{
            scale: [1, 1.02, 1],
            opacity: [0.8, 1, 0.8]
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <p className="text-base sm:text-lg text-muted-foreground mb-2" data-testid="quest-prompt">
            ✨ Ready to explore my journey? ✨
          </p>
          <p className="text-sm text-muted-foreground/70">
            Click the button below to begin!
          </p>
        </motion.div>

        {/* Animated Arrows Pointing Down */}
        <motion.div 
          className="flex justify-center mb-6"
          variants={itemVariants}
        >
          <div className="flex flex-col items-center gap-1">
            <motion.div
              animate={{ y: [0, 8, 0] }}
              transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
            >
              <ChevronDown className="w-6 h-6 text-accent" />
            </motion.div>
            <motion.div
              animate={{ y: [0, 8, 0] }}
              transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut", delay: 0.2 }}
            >
              <ChevronDown className="w-5 h-5 text-accent/70" />
            </motion.div>
            <motion.div
              animate={{ y: [0, 8, 0] }}
              transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut", delay: 0.4 }}
            >
              <ChevronDown className="w-4 h-4 text-accent/40" />
            </motion.div>
          </div>
        </motion.div>

        <motion.div 
          className="flex justify-center"
          variants={itemVariants}
        >
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            animate={{
              boxShadow: [
                "0 0 20px rgba(139, 92, 246, 0.3)",
                "0 0 40px rgba(139, 92, 246, 0.6)",
                "0 0 20px rgba(139, 92, 246, 0.3)"
              ]
            }}
            transition={{
              boxShadow: { duration: 2, repeat: Infinity }
            }}
            className="relative"
          >
            {/* Pulsing ring around button */}
            <motion.div
              className="absolute inset-0 rounded-lg bg-gradient-to-r from-accent to-chart-2 opacity-30"
              animate={{
                scale: [1, 1.1, 1],
                opacity: [0.3, 0.6, 0.3]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
            <Button 
              size="lg"
              className="bg-gradient-to-r from-accent to-chart-2 hover:from-accent/90 hover:to-chart-2/90 text-accent-foreground relative overflow-hidden group w-full sm:w-auto"
              onClick={() => {
                if (onStartQuest) {
                  onStartQuest();
                  setTimeout(() => scrollToSection("about"), 500);
                } else {
                  scrollToSection("about");
                }
              }}
              data-testid="button-start-quest"
            >
              <motion.div
                className="absolute inset-0 bg-white/20"
                initial={{ x: "-100%" }}
                whileHover={{ x: "100%" }}
                transition={{ duration: 0.5 }}
              />
              <Play className="w-4 h-4 mr-2 relative z-10" />
              <span className="relative z-10">Start Quest</span>
            </Button>
          </motion.div>
        </motion.div>
      </motion.div>

      {/* Subtle floating elements */}
      <motion.div 
        className="absolute top-20 left-10 opacity-30"
        variants={floatVariants}
        animate="float"
        style={{ animationDelay: "0s" }}
        data-testid="floating-element-1"
      >
        <div className="w-12 h-12 bg-gradient-to-br from-accent/10 to-chart-2/10 rounded-lg backdrop-blur-sm border border-border/50">
        </div>
      </motion.div>
      
      <motion.div 
        className="absolute bottom-20 right-10 opacity-30"
        variants={floatVariants}
        animate="float"
        style={{ animationDelay: "1s" }}
        data-testid="floating-element-2"
      >
        <div className="w-12 h-12 bg-gradient-to-br from-chart-4/10 to-accent/10 rounded-lg backdrop-blur-sm border border-border/50">
        </div>
      </motion.div>
    </section>
  );
}
