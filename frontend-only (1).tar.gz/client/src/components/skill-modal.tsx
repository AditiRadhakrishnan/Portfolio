import { motion, AnimatePresence } from "framer-motion";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Trophy, Star, Calendar, Zap, ExternalLink } from "lucide-react";

interface SkillModalProps {
  isOpen: boolean;
  onClose: () => void;
  skill: {
    name: string;
    percentage: number;
    color: string;
    category: string;
    description: string;
    experience: string;
    projects: string[];
    achievements: string[];
    learningPath: string[];
  };
}

export function SkillModal({ isOpen, onClose, skill }: SkillModalProps) {
  const modalVariants = {
    hidden: { opacity: 0, scale: 0.8, y: 50 },
    visible: { 
      opacity: 1, 
      scale: 1, 
      y: 0,
      transition: { 
        type: "spring", 
        damping: 15, 
        stiffness: 300 
      }
    },
    exit: { 
      opacity: 0, 
      scale: 0.8, 
      y: 50,
      transition: { duration: 0.2 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: { 
      opacity: 1, 
      x: 0,
      transition: { duration: 0.3 }
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <Dialog open={isOpen} onOpenChange={onClose}>
          <DialogContent className="max-w-[90vw] sm:max-w-[400px] md:max-w-[450px] lg:max-w-[500px] p-0 overflow-hidden max-h-[85vh] overflow-y-auto">
            <motion.div
              variants={modalVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              className="relative"
            >
              {/* Header with animated background */}
              <motion.div 
                className={`p-4 sm:p-6 bg-gradient-to-r ${skill.color.includes('accent') ? 'from-accent/20 to-accent/5' : 'from-chart-2/20 to-chart-2/5'} relative overflow-hidden`}
                initial={{ x: -100 }}
                animate={{ x: 0 }}
                transition={{ delay: 0.2 }}
              >
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
                  animate={{ x: ["-100%", "100%"] }}
                  transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                />
                <DialogHeader className="relative z-10">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.3, type: "spring" }}
                    className="flex items-center gap-3 mb-2"
                  >
                    <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-lg ${skill.color.replace('text-', 'bg-').replace('/10', '/20')} flex items-center justify-center`}>
                      <Zap className="w-5 h-5 sm:w-6 sm:h-6" />
                    </div>
                    <div>
                      <DialogTitle className="text-xl sm:text-2xl font-bold">{skill.name}</DialogTitle>
                      <DialogDescription className="text-base sm:text-lg">{skill.category}</DialogDescription>
                    </div>
                  </motion.div>
                  
                  <motion.div 
                    className="space-y-2"
                    variants={itemVariants}
                    initial="hidden"
                    animate="visible"
                    transition={{ delay: 0.4 }}
                  >
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Mastery Level</span>
                      <span className="text-sm font-bold">{skill.percentage}%</span>
                    </div>
                    <Progress 
                      value={skill.percentage} 
                      className="h-3 bg-background"
                    />
                  </motion.div>
                </DialogHeader>
              </motion.div>

              {/* Content */}
              <div className="p-4 sm:p-6 space-y-4 sm:space-y-6">
                <motion.div
                  variants={itemVariants}
                  initial="hidden"
                  animate="visible"
                  transition={{ delay: 0.5 }}
                >
                  <h3 className="text-base sm:text-lg font-semibold mb-2 flex items-center gap-2">
                    <Star className="w-4 h-4 sm:w-5 sm:h-5 text-chart-4" />
                    Overview
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {skill.description}
                  </p>
                </motion.div>

                <motion.div
                  variants={itemVariants}
                  initial="hidden"
                  animate="visible"
                  transition={{ delay: 0.6 }}
                >
                  <h3 className="text-base sm:text-lg font-semibold mb-2 flex items-center gap-2">
                    <Calendar className="w-4 h-4 sm:w-5 sm:h-5 text-accent" />
                    Experience
                  </h3>
                  <p className="text-muted-foreground">
                    {skill.experience}
                  </p>
                </motion.div>

                <motion.div
                  variants={itemVariants}
                  initial="hidden"
                  animate="visible"
                  transition={{ delay: 0.7 }}
                >
                  <h3 className="text-base sm:text-lg font-semibold mb-3 flex items-center gap-2">
                    <Trophy className="w-4 h-4 sm:w-5 sm:h-5 text-chart-1" />
                    Key Achievements
                  </h3>
                  <div className="space-y-2">
                    {skill.achievements.map((achievement, index) => (
                      <motion.div
                        key={index}
                        className="flex items-center gap-2 p-2 bg-secondary/50 rounded-lg"
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.8 + index * 0.1 }}
                      >
                        <div className="w-2 h-2 bg-chart-1 rounded-full" />
                        <span className="text-sm">{achievement}</span>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>

                <motion.div
                  variants={itemVariants}
                  initial="hidden"
                  animate="visible"
                  transition={{ delay: 0.9 }}
                >
                  <h3 className="text-base sm:text-lg font-semibold mb-3">Related Projects</h3>
                  <div className="flex flex-wrap gap-2">
                    {skill.projects.map((project, index) => (
                      <motion.div
                        key={index}
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ delay: 1.0 + index * 0.1 }}
                      >
                        <Badge variant="secondary" className="cursor-pointer hover:bg-accent/10">
                          {project}
                        </Badge>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>

                <motion.div
                  variants={itemVariants}
                  initial="hidden"
                  animate="visible"
                  transition={{ delay: 1.1 }}
                >
                  <h3 className="text-base sm:text-lg font-semibold mb-3">Learning Journey</h3>
                  <div className="space-y-2">
                    {skill.learningPath.map((step, index) => (
                      <motion.div
                        key={index}
                        className="flex items-center gap-3"
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 1.2 + index * 0.1 }}
                      >
                        <div className="w-6 h-6 bg-accent/20 rounded-full flex items-center justify-center text-xs font-bold">
                          {index + 1}
                        </div>
                        <span className="text-sm">{step}</span>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              </div>

              {/* Footer */}
              <motion.div 
                className="p-4 sm:p-6 border-t bg-secondary/30"
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 1.3 }}
              >
                <div className="flex flex-col sm:flex-row justify-between items-center gap-3 sm:gap-0">
                  <div className="text-xs text-muted-foreground text-center sm:text-left">
                    🎮 Skill unlocked through dedication and practice
                  </div>
                  <Button 
                    onClick={onClose}
                    className="bg-gradient-to-r from-accent to-chart-2 text-sm"
                    size="sm"
                  >
                    Continue Exploring
                  </Button>
                </div>
              </motion.div>
            </motion.div>
          </DialogContent>
        </Dialog>
      )}
    </AnimatePresence>
  );
}