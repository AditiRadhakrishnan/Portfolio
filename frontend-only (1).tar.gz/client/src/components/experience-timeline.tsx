import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface TimelineItemProps {
  title: string;
  organization: string;
  period: string;
  description: string;
  color: string;
  isRight?: boolean;
}

function TimelineItem({ title, organization, period, description, color, isRight }: TimelineItemProps) {
  const itemVariants = {
    hidden: { 
      opacity: 0, 
      x: isRight ? 50 : -50,
      scale: 0.9
    },
    visible: {
      opacity: 1,
      x: 0,
      scale: 1,
      transition: { 
        duration: 0.6,
        ease: "easeOut"
      },
    },
  };

  return (
    <motion.div 
      className="relative flex items-center md:justify-between"
      variants={itemVariants}
    >
      {/* Desktop Layout */}
      <div className={`hidden md:flex items-center ${isRight ? 'md:flex-row-reverse' : ''} w-full`}>
        <div className={`md:w-5/12 ${isRight ? 'md:pl-6' : 'md:pr-6'}`}>
          <Card className="border border-border shadow-sm hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center mb-2">
                <h3 className={`text-lg font-semibold ${color}`} data-testid={`timeline-title-${title.toLowerCase().replace(/\s+/g, '-')}`}>
                  {title}
                </h3>
                <Badge variant="outline" className="ml-auto text-sm">
                  {period}
                </Badge>
              </div>
              <p className="text-muted-foreground text-sm mb-2" data-testid={`timeline-org-${organization.toLowerCase().replace(/\s+/g, '-')}`}>
                {organization}
              </p>
              <p className="text-sm" data-testid={`timeline-desc-${title.toLowerCase().replace(/\s+/g, '-')}`}>
                {description}
              </p>
            </CardContent>
          </Card>
        </div>
        
        {/* Timeline dot for desktop */}
        <div className={`absolute ${isRight ? 'left-6' : 'right-6'} w-4 h-4 ${color.replace('text-', 'bg-')} rounded-full border-4 border-background z-10`} />
        
        <div className="md:w-5/12" />
      </div>

      {/* Mobile Layout */}
      <div className="md:hidden flex items-center w-full">
        <div className="absolute left-6 w-4 h-4 bg-accent rounded-full border-4 border-background z-10" />
        <div className="ml-16 w-full">
          <Card className="border border-border shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center mb-2">
                <h3 className={`text-lg font-semibold ${color}`} data-testid={`mobile-timeline-title-${title.toLowerCase().replace(/\s+/g, '-')}`}>
                  {title}
                </h3>
                <Badge variant="outline" className="ml-auto text-sm">
                  {period}
                </Badge>
              </div>
              <p className="text-muted-foreground text-sm mb-2" data-testid={`mobile-timeline-org-${organization.toLowerCase().replace(/\s+/g, '-')}`}>
                {organization}
              </p>
              <p className="text-sm" data-testid={`mobile-timeline-desc-${title.toLowerCase().replace(/\s+/g, '-')}`}>
                {description}
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </motion.div>
  );
}

export default function ExperienceTimeline() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.3,
      },
    },
  };

  const experiences = [
    {
      title: "UC Berkeley",
      organization: "Data Science Student",
      period: "2024 - 2026",
      description: "Pursuing B.A. in Data Science with Domain Emphasis in Business and Industrial Analytics",
      color: "text-accent",
      isRight: false,
    },
    {
      title: "Software Developer",
      organization: "Aryal • Self-employed",
      period: "2024",
      description: "Full-stack web development and technical consulting projects",
      color: "text-chart-2",
      isRight: true,
    },
    {
      title: "Animal Rescue Volunteer",
      organization: "Animal Rescue of Tracy & Rocketdog Rescue",
      period: "2021 - 2024",
      description: "Rescued and cared for animals, managed website and social media. Recognized nationally for volunteer work and technology contributions to animal welfare.",
      color: "text-chart-4",
      isRight: false,
    },
    {
      title: "Red Cross Volunteer",
      organization: "American Red Cross",
      period: "2021 - 2024",
      description: "Supported humanitarian efforts and disaster relief initiatives through community service and emergency preparedness programs.",
      color: "text-destructive",
      isRight: true,
    },
    {
      title: "Website Developer",
      organization: "Sanatan Mandir San Bruno",
      period: "2018 - 2019",
      description: "Led website development and activity scheduling systems. Coordinated volunteer alignment with class schedules and organized food donation drives.",
      color: "text-chart-1",
      isRight: false,
    },
    {
      title: "Community Service Volunteer",
      organization: "SF City Impact Rescue Mission",
      period: "2019 - 2022",
      description: "Distributed meals and essential resources to homeless population. Played crucial role in food pantry operations supporting vulnerable communities.",
      color: "text-chart-3",
      isRight: true,
    },
  ];

  return (
    <section id="experience" className="py-20" data-testid="experience-section">
      <div className="max-w-6xl mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="experience-title">
            Experience Timeline
          </h2>
          <p className="text-muted-foreground text-lg" data-testid="experience-subtitle">
            Leveling up through real-world adventures
          </p>
        </motion.div>

        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-8 md:left-1/2 transform md:-translate-x-px top-0 bottom-0 w-0.5 bg-border" />

          <motion.div 
            className="space-y-12"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
          >
            {experiences.map((experience, index) => (
              <TimelineItem 
                key={`${experience.title}-${index}`}
                {...experience}
              />
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
