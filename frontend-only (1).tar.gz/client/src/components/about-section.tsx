import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CloudUpload, Rocket, Heart, ExternalLink } from "lucide-react";

export default function AboutSection() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  return (
    <section id="about" className="py-20 bg-secondary/30" data-testid="about-section">
      <div className="max-w-6xl mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
        >
          <motion.h2 
            className="text-3xl md:text-4xl font-bold mb-4"
            variants={itemVariants}
            data-testid="about-title"
          >
            Character Profile
          </motion.h2>
          <motion.p 
            className="text-muted-foreground text-lg"
            variants={itemVariants}
            data-testid="about-subtitle"
          >
            Understanding the player behind the code
          </motion.p>
        </motion.div>

        <motion.div 
          className="grid md:grid-cols-2 gap-12 items-center"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
        >
          <div className="space-y-6">
            <motion.div variants={itemVariants}>
              <Card className="border border-border shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-4 text-accent flex items-center" data-testid="mission-statement-title">
                    <CloudUpload className="w-5 h-5 mr-2" />
                    Mission Statement
                  </h3>
                  <p className="text-muted-foreground leading-relaxed" data-testid="mission-statement-text">
                    I am a Data Science student at UC Berkeley who thrives on collaborative problem-solving and creating meaningful impact. 
                    I love bringing people together, mentoring peers, and tackling challenges with unique approaches that make a difference in society.
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={itemVariants}>
              <Card className="border border-border shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-4 text-chart-2 flex items-center" data-testid="current-quest-title">
                    <Rocket className="w-5 h-5 mr-2" />
                    Current Quest
                  </h3>
                  <p className="text-muted-foreground leading-relaxed" data-testid="current-quest-text">
                    Actively seeking data science internships to gain hands-on workforce experience while continuing to build 
                    innovative solutions that connect communities and solve real-world problems.
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={itemVariants}>
              <Card className="border border-border shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-4 text-chart-4 flex items-center" data-testid="core-values-title">
                    <Heart className="w-5 h-5 mr-2" />
                    Core Values
                  </h3>
                  <div className="grid grid-cols-2 gap-3" data-testid="core-values-grid">
                    <Badge variant="secondary" className="justify-center py-2">Collaboration</Badge>
                    <Badge variant="secondary" className="justify-center py-2">Innovation</Badge>
                    <Badge variant="secondary" className="justify-center py-2">Impact</Badge>
                    <Badge variant="secondary" className="justify-center py-2">Mentorship</Badge>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          <motion.div 
            className="space-y-6"
            variants={itemVariants}
          >
            <div className="bg-gradient-to-br from-accent/10 to-chart-2/10 rounded-xl p-8 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-accent/5 rounded-full -translate-y-16 translate-x-16"></div>
              <div className="absolute bottom-0 left-0 w-24 h-24 bg-chart-2/5 rounded-full translate-y-12 -translate-x-12"></div>
              
              <h3 className="text-xl font-semibold mb-6 text-primary" data-testid="stats-overview-title">
                Stats Overview
              </h3>
              
              <div className="space-y-4" data-testid="stats-overview-list">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Projects Completed</span>
                  <span className="font-bold text-accent">8+</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Years Experience</span>
                  <span className="font-bold text-chart-2">3+</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Community Impact</span>
                  <span className="font-bold text-chart-4">500+</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Recognition Level</span>
                  <span className="font-bold text-chart-1">National</span>
                </div>
              </div>

              <div className="mt-6 flex flex-wrap gap-2" data-testid="live-projects-links">
                <a 
                  href="https://findmypaw.org" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-accent hover:text-accent/80 text-sm bg-accent/10 px-3 py-1 rounded-full transition-colors flex items-center gap-1"
                  data-testid="link-findmypaw"
                >
                  🐾 findmypaw.org
                  <ExternalLink className="w-3 h-3" />
                </a>
                <a 
                  href="https://watchmywallet.org" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-chart-2 hover:text-chart-2/80 text-sm bg-chart-2/10 px-3 py-1 rounded-full transition-colors flex items-center gap-1"
                  data-testid="link-watchmywallet"
                >
                  💰 watchmywallet.org
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
