import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertContactSchema } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Rocket, Mail, Linkedin, MapPin, Clock, PawPrint, Wallet, Download, Wand2 } from "lucide-react";
import type { InsertContact } from "@shared/schema";

export default function ContactSection() {
  const { toast } = useToast();

  const form = useForm<InsertContact>({
    resolver: zodResolver(insertContactSchema),
    defaultValues: {
      name: "",
      email: "",
      questType: "",
      message: "",
    },
  });

  const contactMutation = useMutation({
    mutationFn: (data: InsertContact) => apiRequest("POST", "/api/contact", data),
    onSuccess: () => {
      toast({
        title: "Quest Launched! 🚀",
        description: "Your message has been sent successfully. I'll get back to you within 24 hours!",
      });
      form.reset();
    },
    onError: () => {
      toast({
        title: "Quest Failed",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertContact) => {
    contactMutation.mutate(data);
  };

  const handleResumeDownload = async () => {
    try {
      await apiRequest("GET", "/api/resume/download");
      window.open("/resume_aditi_radhakrishnan.pdf", "_blank");
    } catch (error) {
      console.error("Failed to track resume download:", error);
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  return (
    <section id="contact" className="py-20" data-testid="contact-section">
      <div className="max-w-4xl mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="contact-title">
            Start a New Quest
          </h2>
          <p className="text-muted-foreground text-lg" data-testid="contact-subtitle">
            Ready to collaborate? Let's create something amazing together!
          </p>
        </motion.div>

        <motion.div 
          className="grid md:grid-cols-2 gap-12"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
        >
          {/* Contact Info */}
          <div className="space-y-6">
            <motion.div variants={itemVariants}>
              <Card className="border border-border shadow-sm">
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-6 flex items-center" data-testid="player-info-title">
                    <Rocket className="text-accent mr-2" />
                    Player Info
                  </h3>
                  
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3" data-testid="contact-email">
                      <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center">
                        <Mail className="text-accent w-5 h-5" />
                      </div>
                      <div>
                        <div className="font-medium">Email</div>
                        <div className="text-sm text-muted-foreground">aditirad@berkeley.edu</div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3" data-testid="contact-linkedin">
                      <div className="w-10 h-10 bg-chart-2/10 rounded-lg flex items-center justify-center">
                        <Linkedin className="text-chart-2 w-5 h-5" />
                      </div>
                      <div>
                        <div className="font-medium">LinkedIn</div>
                        <div className="text-sm text-muted-foreground">linkedin.com/in/aditirad</div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3" data-testid="contact-location">
                      <div className="w-10 h-10 bg-chart-4/10 rounded-lg flex items-center justify-center">
                        <MapPin className="text-chart-4 w-5 h-5" />
                      </div>
                      <div>
                        <div className="font-medium">Location</div>
                        <div className="text-sm text-muted-foreground">San Francisco Bay Area</div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3" data-testid="contact-status">
                      <div className="w-10 h-10 bg-chart-1/10 rounded-lg flex items-center justify-center">
                        <Clock className="text-chart-1 w-5 h-5" />
                      </div>
                      <div>
                        <div className="font-medium">Status</div>
                        <Badge className="bg-chart-2/10 text-chart-2 text-xs">
                          Available for Internships
                        </Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={itemVariants}>
              <Card className="border border-border shadow-sm">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-4" data-testid="quick-links-title">
                    Quick Links
                  </h3>
                  <div className="space-y-3">
                    <a 
                      href="https://findmypaw.org" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center space-x-3 text-accent hover:text-accent/80 transition-colors"
                      data-testid="link-findmypaw"
                    >
                      <PawPrint className="w-4 h-4" />
                      <span>FindMyPaw.org</span>
                    </a>
                    <a 
                      href="https://watchmywallet.org" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center space-x-3 text-chart-4 hover:text-chart-4/80 transition-colors"
                      data-testid="link-watchmywallet"
                    >
                      <Wallet className="w-4 h-4" />
                      <span>WatchMyWallet.org</span>
                    </a>
                    <button 
                      onClick={handleResumeDownload}
                      className="flex items-center space-x-3 text-chart-2 hover:text-chart-2/80 transition-colors"
                      data-testid="button-download-resume"
                    >
                      <Download className="w-4 h-4" />
                      <span>Download Resume</span>
                    </button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Contact Form */}
          <motion.div variants={itemVariants}>
            <Card className="border border-border shadow-sm">
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-6 flex items-center" data-testid="send-message-title">
                  <Wand2 className="text-accent mr-2" />
                  Send Message
                </h3>
                
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4" data-testid="contact-form">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Your Name</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Enter your name" 
                              {...field} 
                              data-testid="input-name"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Address</FormLabel>
                          <FormControl>
                            <Input 
                              type="email"
                              placeholder="your.email@example.com" 
                              {...field} 
                              data-testid="input-email"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="questType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Quest Type</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-quest-type">
                                <SelectValue placeholder="Select quest type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="Internship Opportunity">Internship Opportunity</SelectItem>
                              <SelectItem value="Project Collaboration">Project Collaboration</SelectItem>
                              <SelectItem value="Mentorship">Mentorship</SelectItem>
                              <SelectItem value="General Inquiry">General Inquiry</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="message"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Message</FormLabel>
                          <FormControl>
                            <Textarea 
                              rows={4}
                              placeholder="Tell me about your quest..."
                              className="resize-none"
                              {...field} 
                              data-testid="textarea-message"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button 
                      type="submit" 
                      className="w-full bg-gradient-to-r from-accent to-accent/80 hover:from-accent/90 hover:to-accent/70"
                      disabled={contactMutation.isPending}
                      data-testid="button-submit-quest"
                    >
                      {contactMutation.isPending ? (
                        <div className="flex items-center">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                          Launching...
                        </div>
                      ) : (
                        <>
                          <Wand2 className="w-4 h-4 mr-2" />
                          Launch Quest
                        </>
                      )}
                    </Button>
                  </form>
                </Form>

                <div className="mt-6 text-center">
                  <p className="text-xs text-muted-foreground" data-testid="response-time-info">
                    🎮 Response time: Usually within 24 hours • All quests welcome!
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
