import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import AboutSection from "@/components/about-section";
import SkillsSection from "@/components/skills-section";
import ProjectsSection from "@/components/projects-section";
import ExperienceTimeline from "@/components/experience-timeline";
import AchievementsSection from "@/components/achievements-section";
import AwardsGallery from "@/components/awards-gallery";
import CharacterProfile from "@/components/character-profile";
import ContactSection from "@/components/contact-section";
import Footer from "@/components/footer";
import { useEasterEggs } from "@/hooks/use-easter-eggs";
import { useState } from "react";

export default function Home() {
  const [questStarted, setQuestStarted] = useState(false);
  useEasterEggs();

  const handleStartQuest = () => {
    setQuestStarted(true);
  };

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      <Navigation />
      <HeroSection onStartQuest={handleStartQuest} />
      {questStarted && (
        <>
          <AboutSection />
          <SkillsSection />
          <ProjectsSection />
          <ExperienceTimeline />
          <AchievementsSection />
          <AwardsGallery />
          <CharacterProfile />
          <ContactSection />
          <Footer />
        </>
      )}
    </div>
  );
}
