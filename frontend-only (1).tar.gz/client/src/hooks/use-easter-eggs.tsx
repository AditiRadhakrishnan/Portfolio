import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

export function useEasterEggs() {
  const [easterEggCount, setEasterEggCount] = useState(0);
  const { toast } = useToast();

  useEffect(() => {
    // Konami code easter egg
    const konamiCode = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'KeyB', 'KeyA'];
    let userInput: string[] = [];

    const handleKeyDown = (e: KeyboardEvent) => {
      userInput.push(e.code);
      if (userInput.length > konamiCode.length) {
        userInput.shift();
      }
      
      if (JSON.stringify(userInput) === JSON.stringify(konamiCode)) {
        setEasterEggCount(prev => prev + 1);
        showKonamiReward();
        userInput = [];
      }
    };

    // Secret click combinations
    let clickCount = 0;
    const handleClick = (e: MouseEvent) => {
      if (e.ctrlKey && e.shiftKey) {
        clickCount++;
        if (clickCount >= 5) {
          setEasterEggCount(prev => prev + 1);
          toast({
            title: "Secret Combination! 🎮",
            description: "You discovered the Ctrl+Shift+Click combo!",
          });
          clickCount = 0;
        }
      }
    };

    // Add event listeners
    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('click', handleClick);

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('click', handleClick);
    };
  }, [toast]);

  const showKonamiReward = () => {
    // Create modal for Konami code reward
    const modal = document.createElement('div');
    modal.className = 'fixed inset-0 bg-black/50 z-50 flex items-center justify-center';
    modal.style.backdropFilter = 'blur(5px)';
    
    modal.innerHTML = `
      <div class="bg-card rounded-xl p-8 border border-border shadow-2xl text-center max-w-md animate-bounce-in">
        <div class="text-6xl mb-4">🎮</div>
        <h3 class="text-2xl font-bold mb-4 text-accent">Konami Code Unlocked!</h3>
        <p class="text-muted-foreground mb-6">
          You're a true gamer! This classic cheat code dates back to the 1980s.
        </p>
        <button class="bg-accent text-accent-foreground px-6 py-2 rounded-lg font-semibold hover:bg-accent/90 transition-colors">
          Awesome!
        </button>
      </div>
    `;
    
    document.body.appendChild(modal);
    
    // Add click handler to close
    const button = modal.querySelector('button');
    button?.addEventListener('click', () => {
      modal.remove();
    });
    
    // Auto remove after 5 seconds
    setTimeout(() => {
      if (document.body.contains(modal)) {
        modal.remove();
      }
    }, 5000);
    
    // Create celebration effect
    createCelebrationEffect();
    
    toast({
      title: "Konami Code Activated! 🎉",
      description: "↑↑↓↓←→←→BA - The legendary sequence!",
    });
  };

  const createCelebrationEffect = () => {
    const emojis = ['🎉', '🎊', '⭐', '🌟'];
    
    for (let i = 0; i < 20; i++) {
      setTimeout(() => {
        const confetti = document.createElement('div');
        confetti.innerHTML = emojis[Math.floor(Math.random() * emojis.length)];
        confetti.style.position = 'fixed';
        confetti.style.left = Math.random() * window.innerWidth + 'px';
        confetti.style.top = '-50px';
        confetti.style.fontSize = '24px';
        confetti.style.zIndex = '9999';
        confetti.style.pointerEvents = 'none';
        confetti.className = 'animate-fall';
        document.body.appendChild(confetti);
        
        setTimeout(() => {
          confetti.remove();
        }, 3000);
      }, i * 100);
    }
  };

  const incrementEasterEgg = () => {
    setEasterEggCount(prev => prev + 1);
  };

  return {
    easterEggCount,
    incrementEasterEgg,
    createCelebrationEffect,
  };
}
